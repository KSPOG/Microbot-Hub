package net.runelite.client.plugins.microbot.kspmadcow;

import net.runelite.api.Actor;
import net.runelite.api.EnumComposition;
import net.runelite.api.EquipmentInventorySlot;
import net.runelite.api.EnumID;
import net.runelite.api.GraphicsObject;
import net.runelite.api.MenuAction;
import net.runelite.api.NPCComposition;
import net.runelite.api.Perspective;
import net.runelite.api.Point;
import net.runelite.api.NPC;
import net.runelite.api.ParamID;
import net.runelite.api.Player;
import net.runelite.api.Skill;
import net.runelite.api.StructComposition;
import net.runelite.api.coords.LocalPoint;
import net.runelite.api.coords.WorldArea;
import net.runelite.api.coords.WorldPoint;
import net.runelite.api.gameval.AnimationID;
import net.runelite.api.gameval.SpotanimID;
import net.runelite.api.gameval.VarPlayerID;
import net.runelite.api.gameval.VarbitID;
import net.runelite.api.widgets.WidgetInfo;
import net.runelite.client.plugins.microbot.Microbot;
import net.runelite.client.plugins.microbot.Script;
import net.runelite.client.plugins.microbot.api.npc.models.Rs2NpcModel;
import net.runelite.client.plugins.microbot.api.tileitem.models.Rs2TileItemModel;
import net.runelite.client.plugins.microbot.api.tileobject.models.Rs2TileObjectModel;
import net.runelite.client.plugins.microbot.globval.enums.InterfaceTab;
import net.runelite.client.plugins.microbot.util.bank.Rs2Bank;
import net.runelite.client.plugins.microbot.util.combat.Rs2Combat;
import net.runelite.client.plugins.microbot.util.coords.Rs2LocalPoint;
import net.runelite.client.plugins.microbot.util.dialogues.Rs2Dialogue;
import net.runelite.client.plugins.microbot.util.equipment.Rs2Equipment;
import net.runelite.client.plugins.microbot.util.inventory.Rs2Inventory;
import net.runelite.client.plugins.microbot.util.inventory.Rs2ItemModel;
import net.runelite.client.plugins.microbot.util.keyboard.Rs2Keyboard;
import net.runelite.client.plugins.microbot.util.menu.NewMenuEntry;
import net.runelite.client.plugins.microbot.util.magic.Rs2Magic;
import net.runelite.client.plugins.microbot.util.magic.Runes;
import net.runelite.client.plugins.microbot.util.misc.Rs2UiHelper;
import net.runelite.client.plugins.microbot.util.player.Rs2Player;
import net.runelite.client.plugins.microbot.util.prayer.Rs2Prayer;
import net.runelite.client.plugins.microbot.util.prayer.Rs2PrayerEnum;
import net.runelite.client.plugins.microbot.util.tabs.Rs2Tab;
import net.runelite.client.plugins.microbot.util.tile.Rs2Tile;
import net.runelite.client.plugins.microbot.util.walker.Rs2Walker;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.BooleanSupplier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Singleton
public class KspMadCowScript extends Script {
    private static final Logger log = LoggerFactory.getLogger(KspMadCowScript.class);
    public enum CombatMode {
        MELEE("Melee"),
        RANGED("Ranged"),
        MAGIC("Magic");

        private final String displayName;

        CombatMode(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    private enum SpecialAttack {
        NONE,
        CHARGE,
        STOMP
    }

    public static final int BRUTUS_ID = 15626;
    public static final int BRUTUS_ALT_ID = 15627;
    public static final int MOOLETA_ID = 33101;
    public static final int COWBELL_EMPTY_ID = 33103;
    public static final int COWBELL_CHARGED_ID = 33104;
    public static final int AIR_RUNE_ID = 556;
    public static final int ALTAR_ID = 409;

    private static final WorldPoint ALTAR_LOCATION = new WorldPoint(3243, 3207, 0);
    private static final WorldArea ALTAR_AREA = new WorldArea(new WorldPoint(3240, 3204, 0), 8, 6);

    /** Polling interval only; action execution itself has no artificial cooldowns. */
    private static final long LOOP_INTERVAL_MS = 100L;

    private static final String BRUTUS_NAME = "Brutus";
    private static final String COWBELL_TRAVEL_ACTION = "Teleport";
    private static final String[] PEN_ENTRY_ACTIONS = {"Release", "Quick-enter", "Enter"};
    private static final int PEN_ENTRY_RETRY_TICKS = 4;
    private static final String[] QUICK_ESCAPE_ACTIONS = {"Quick-escape", "Quick escape"};

    private static final Set<Integer> CHARGE_ANIMATIONS = Set.of(
            AnimationID.COW_BOSS_HEAVY_BREATH,
            AnimationID.COW_BOSS_CHARGE,
            AnimationID.COW_BOSS_CHARGING_FADE_IN_FADE_OUT,
            AnimationID.COW_BOSS_GHOST_CHARGING_FADE_IN_FADE_OUT,
            AnimationID.COW_BOSS_CHARGE_START_FADE_OUT,
            AnimationID.COW_BOSS_GHOST_CHARGE_START_FADE_OUT,
            AnimationID.COW_BOSS_CHARGE_END_FADE_IN,
            AnimationID.COW_BOSS_GHOST_CHARGE_END_FADE_IN
    );

    private static final Set<Integer> STOMP_ANIMATIONS = Set.of(
            AnimationID.COW_BOSS_STOMP,
            AnimationID.COW_BOSS_GHOST_STOMP,
            AnimationID.COW_BOSS_SPIRIT_STOMP,
            AnimationID.COW_BOSS_GHOST_SPIRIT_STOMP,
            AnimationID.COW_BOSS_STOMP_FADE_IN,
            AnimationID.COW_BOSS_GHOST_STOMP_FADE_IN
    );

    private static final Set<Integer> STOMP_GRAPHICS = Set.of(
            SpotanimID.VFX_COWBOSS_STOMP_IMPACT01,
            SpotanimID.VFX_COWBOSS_STOMP_IMPACT02,
            SpotanimID.VFX_COWBOSS_STOMP_IMPACT03
    );

    /** Retain marker tiles long enough to cover one complete Stomp sequence. */
    private static final int STOMP_GRAPHICS_LIFETIME_TICKS = 6;
    /** Do not issue a second Stomp re-attack while the first click is being registered. */
    private static final int STOMP_REATTACK_CONFIRM_TICKS = 2;
    /** Wait for a rejected local scene-walk request to prove stalled before retrying. */
    private static final int SPECIAL_MOVEMENT_RETRY_STALL_TICKS = 2;
    /** A single dodge may issue at most two requests to one target before using the other candidate. */
    private static final int SPECIAL_MOVEMENT_ATTEMPTS_PER_TARGET = 2;

    private static final String[] MELEE_COMBINED_POTIONS = {
            "Super combat potion", "Combat potion", "Divine super combat potion"
    };
    private static final String[] ATTACK_POTIONS = {
            "Super attack", "Attack potion", "Divine super attack potion"
    };
    private static final String[] STRENGTH_POTIONS = {
            "Super strength", "Strength potion", "Divine super strength potion"
    };
    private static final String[] DEFENCE_POTIONS = {
            "Super defence", "Defence potion", "Divine super defence potion"
    };
    private static final String[] RANGED_POTIONS = {
            "Ranging potion", "Bastion potion", "Divine ranging potion", "Divine bastion potion"
    };
    private static final String[] MAGIC_POTIONS = {
            "Magic potion", "Battlemage potion", "Divine magic potion", "Divine battlemage potion"
    };

    private static final WidgetInfo[] MELEE_STYLE_WIDGETS = {
            WidgetInfo.COMBAT_STYLE_ONE,
            WidgetInfo.COMBAT_STYLE_TWO,
            WidgetInfo.COMBAT_STYLE_THREE,
            WidgetInfo.COMBAT_STYLE_FOUR
    };

    private static final Rs2PrayerEnum[] MANAGED_COMBAT_PRAYERS = {
            Rs2PrayerEnum.CLARITY_THOUGHT,
            Rs2PrayerEnum.IMPROVED_REFLEXES,
            Rs2PrayerEnum.INCREDIBLE_REFLEXES,
            Rs2PrayerEnum.SUPERHUMAN_STRENGTH,
            Rs2PrayerEnum.ULTIMATE_STRENGTH,
            Rs2PrayerEnum.SHARP_EYE,
            Rs2PrayerEnum.HAWK_EYE,
            Rs2PrayerEnum.EAGLE_EYE,
            Rs2PrayerEnum.MYSTIC_WILL,
            Rs2PrayerEnum.MYSTIC_LORE,
            Rs2PrayerEnum.MYSTIC_MIGHT,
            Rs2PrayerEnum.PROTECT_MELEE
    };

    private KspMadCowConfig config;
    private Runnable stopRequest;

    private volatile KspMadCowState state = KspMadCowState.STOPPED;
    private volatile Skill trainingSkill = Skill.ATTACK;
    private volatile int killCount;
    private volatile String lastMessage = "Stopped";
    private volatile CombatMode combatMode = CombatMode.MELEE;
    private volatile String activePrayerSummary = "None";
    private volatile boolean brutusAlive;
    private volatile int trackedRangedAmmoId = -1;
    private volatile String trackedRangedAmmoName = "";
    private int lastCombatGearWeaponId = Integer.MIN_VALUE;
    private int lastCombatGearAmmoId = Integer.MIN_VALUE;
    private CombatMode lastLoggedCombatMode;

    private volatile boolean running;
    private boolean initialBankCheckPending = true;
    private boolean instanceConfirmed;
    private boolean clientInstanceDetected;
    private boolean travelRequired = true;
    private boolean cowbellTravelIssued;
    private long cowbellChargeAttemptRevision = -1L;
    private int cowbellChargeAttemptTick = Integer.MIN_VALUE;
    private boolean cowbellChargeInputPending;
    private boolean cowbellChargeInputSubmitted;
    private int cowbellChargeInputAmount;
    private int cowbellChargeInputSubmitTick = Integer.MIN_VALUE;
    private String lastPenEntryAction = "";
    private int lastPenEntryAttemptTick = Integer.MIN_VALUE;
    private boolean leavingInstance;
    private boolean quickLeaveClickIssued;
    private boolean altarInteractionIssued;
    private boolean bankActionPending;
    private long bankActionInventoryRevision;
    private String bankActionDescription = "";
    private BooleanSupplier bankActionComplete;
    private boolean suppliesErrorShown;
    private boolean altarRestorePending;
    private int altarPrayerPointsBeforeInteraction = -1;
    private boolean altarTeleportPending;
    private boolean combatReacquirePending;
    private int lastCombatAttackTick = Integer.MIN_VALUE;
    private boolean healActionPending;
    private long healActionInventoryRevision = -1L;
    private int healActionHpBefore = -1;
    private int healActionIssuedTick = Integer.MIN_VALUE;
    private boolean killArmed;
    private volatile boolean prayersSuppressedUntilRespawn;
    private volatile NPC lastKnownBrutusNpc;

    private volatile SpecialAttack activeSpecial = SpecialAttack.NONE;
    private SpecialAttack pendingSpecial = SpecialAttack.NONE;
    private boolean pendingSpecialFromAnimation;
    private int pendingSpecialAnimation = -1;
    private WorldArea pendingSpecialArea;
    private int pendingSpecialOrientation = -1;
    private SpecialAttack cuePrimedAttack = SpecialAttack.NONE;
    private int cuePrimedTick = Integer.MIN_VALUE;
    private boolean chargeSequenceLatched;
    private boolean chargeSequenceAnimationObserved;
    private boolean stompSequenceLatched;
    private boolean specialAnimationObserved;
    private boolean specialMovementAttempted;
    private int lastSpecialMovementTick = Integer.MIN_VALUE;
    private int specialMovementIssueCount;
    private int specialMovementTargetAttempts;
    private int specialMovementLastProgressTick = Integer.MIN_VALUE;
    private WorldPoint specialMovementLastPlayerLocation;
    private final Set<WorldPoint> specialMovementIssuedTargets = new HashSet<>();
    private boolean specialTargetReached;
    private WorldPoint specialDodgeTarget;
    private List<WorldPoint> specialDodgeCandidates = List.of();
    private int specialCandidateIndex;
    private int currentBrutusAnimation = -1;
    private int currentBrutusAnimationFrame = -1;
    private int lastObservedBrutusAnimation = Integer.MIN_VALUE;
    private int lastObservedBrutusFrame = -1;
    private String lastObservedOverheadCue = "";
    private int lastSpecialReattackTick = Integer.MIN_VALUE;
    private int activeSpecialStartedTick = Integer.MIN_VALUE;
    private int stompActivationTick = Integer.MIN_VALUE;
    private boolean stompReattackIssued;
    private int stompReattackIssuedTick = Integer.MIN_VALUE;
    private int lastCombatBlockedLogTick = Integer.MIN_VALUE;
    private String lastCombatBlockedReason = "";
    private int lastRangedAmmoEquipTick = Integer.MIN_VALUE;
    private int lastHealDebugTick = Integer.MIN_VALUE;
    private int lastPotionDebugTick = Integer.MIN_VALUE;

    private final ConcurrentHashMap<WorldPoint, Integer> stompImpactTileTicks = new ConcurrentHashMap<>();
    private final AtomicLong inventoryRevision = new AtomicLong();
    private long startedAtNanos;
    private long stoppedElapsedMillis;

    private volatile OverlaySnapshot overlaySnapshot = OverlaySnapshot.stopped();

    @Inject
    public KspMadCowScript() {
    }

    public synchronized boolean run(KspMadCowConfig config, Runnable stopRequest) {
        if (running) {
            return false;
        }

        if (scheduledExecutorService == null || scheduledExecutorService.isShutdown()) {
            scheduledExecutorService = Executors.newSingleThreadScheduledExecutor(new ScriptThreadFactory());
        }

        this.config = Objects.requireNonNull(config);
        this.stopRequest = stopRequest;
        resetForStart();
        Microbot.enableAutoRunOn = config.autoRun();
        visibleDebug("Lifecycle", "KSP Mad Cow v" + KspMadCowPlugin.VERSION
                + " started; combat movement mode=canvas-only; minimap disabled");

        mainScheduledFuture = scheduledExecutorService.scheduleWithFixedDelay(() -> {
            if (!running || Thread.currentThread().isInterrupted()) {
                return;
            }

            try {
                if (!Microbot.isLoggedIn() || !super.run()) {
                    refreshOverlaySnapshot();
                    return;
                }
                tick();
            } catch (Exception ex) {
                setState(KspMadCowState.ERROR, "Unexpected error: " + ex.getClass().getSimpleName());
                Microbot.logStackTrace(getClass().getSimpleName(), ex);
            } finally {
                refreshOverlaySnapshot();
            }
        }, 0L, LOOP_INTERVAL_MS, TimeUnit.MILLISECONDS);

        return true;
    }

    private void resetForStart() {
        state = KspMadCowState.STARTING;
        trainingSkill = Skill.ATTACK;
        killCount = 0;
        lastMessage = "Starting";
        combatMode = CombatMode.MELEE;
        activePrayerSummary = "None";
        brutusAlive = false;
        trackedRangedAmmoId = -1;
        trackedRangedAmmoName = "";
        lastCombatGearWeaponId = Integer.MIN_VALUE;
        lastCombatGearAmmoId = Integer.MIN_VALUE;
        lastLoggedCombatMode = null;
        running = true;
        initialBankCheckPending = true;
        instanceConfirmed = false;
        clientInstanceDetected = false;
        travelRequired = true;
        cowbellTravelIssued = false;
        cowbellChargeAttemptRevision = -1L;
        cowbellChargeAttemptTick = Integer.MIN_VALUE;
        clearCowbellChargeInputState();
        lastPenEntryAction = "";
        lastPenEntryAttemptTick = Integer.MIN_VALUE;
        leavingInstance = false;
        quickLeaveClickIssued = false;
        altarInteractionIssued = false;
        bankActionPending = false;
        bankActionDescription = "";
        bankActionComplete = null;
        suppliesErrorShown = false;
        altarRestorePending = false;
        altarPrayerPointsBeforeInteraction = -1;
        altarTeleportPending = false;
        combatReacquirePending = false;
        lastCombatAttackTick = Integer.MIN_VALUE;
        clearHealActionState();
        killArmed = false;
        prayersSuppressedUntilRespawn = false;
        lastKnownBrutusNpc = null;
        clearSpecialAvoidance();
        pendingSpecial = SpecialAttack.NONE;
        cuePrimedAttack = SpecialAttack.NONE;
        cuePrimedTick = Integer.MIN_VALUE;
        chargeSequenceLatched = false;
        chargeSequenceAnimationObserved = false;
        stompSequenceLatched = false;
        currentBrutusAnimation = -1;
        currentBrutusAnimationFrame = -1;
        lastObservedBrutusAnimation = Integer.MIN_VALUE;
        lastObservedBrutusFrame = -1;
        lastObservedOverheadCue = "";
        lastSpecialReattackTick = Integer.MIN_VALUE;
        activeSpecialStartedTick = Integer.MIN_VALUE;
        lastSpecialMovementTick = Integer.MIN_VALUE;
        specialMovementIssueCount = 0;
        specialMovementTargetAttempts = 0;
        specialMovementLastProgressTick = Integer.MIN_VALUE;
        specialMovementLastPlayerLocation = null;
        specialMovementIssuedTargets.clear();
        stompActivationTick = Integer.MIN_VALUE;
        stompReattackIssued = false;
        stompReattackIssuedTick = Integer.MIN_VALUE;
        lastCombatBlockedLogTick = Integer.MIN_VALUE;
        lastCombatBlockedReason = "";
        lastRangedAmmoEquipTick = Integer.MIN_VALUE;
        lastHealDebugTick = Integer.MIN_VALUE;
        lastPotionDebugTick = Integer.MIN_VALUE;
        stompImpactTileTicks.clear();
        startedAtNanos = System.nanoTime();
        stoppedElapsedMillis = 0L;
        overlaySnapshot = OverlaySnapshot.starting();
    }

    private void tick() {
        if (!running) {
            return;
        }

        pruneStompImpactTiles();

        // The Cowbell charge quantity prompt is a chatbox numeric input, not a
        // normal dialogue option. Handle it before every other script action so
        // banking/travel logic cannot run while the prompt is waiting for input.
        if (handleCowbellChargeAmountInput()) {
            return;
        }

        if (handleEntryDialogue()) {
            return;
        }

        if (config.autoRetaliate()) {
            Rs2Combat.setAutoRetaliate(true);
        }

        combatMode = detectCombatMode();
        Rs2NpcModel brutus = findBrutus();
        boolean visibleBossAlive = isAlive(brutus);
        ObjectAction quickLeave = findObjectAction(QUICK_ESCAPE_ACTIONS);
        clientInstanceDetected = isClientInInstancedRegion();

        if (leavingInstance) {
            handleLeavingInstance(quickLeave);
            return;
        }

        boolean insideInstance = clientInstanceDetected || quickLeave != null;
        if (insideInstance) {
            instanceConfirmed = true;
            travelRequired = false;
            cowbellTravelIssued = false;
            lastPenEntryAction = "";
            lastPenEntryAttemptTick = Integer.MIN_VALUE;
            brutusAlive = visibleBossAlive;
            if (brutus != null && brutus.getNpc() != null) {
                lastKnownBrutusNpc = brutus.getNpc();
            }
            if (visibleBossAlive) {
                killArmed = true;
                // ActorDeath suppresses combat prayers for the whole respawn gap. A
                // newly alive Brutus is the only state that releases that suppression.
                prayersSuppressedUntilRespawn = false;
            }
            handleInsideInstance(brutus, visibleBossAlive, quickLeave);
            return;
        }

        if (instanceConfirmed) {
            // Covers manual exits and map transitions that did not originate from our gate click.
            instanceConfirmed = false;
            initialBankCheckPending = true;
            travelRequired = false;
            killArmed = false;
        }

        brutusAlive = false;
        resetSpecialDetection();
        handleOutsideInstance();
    }

    private void handleInsideInstance(Rs2NpcModel brutus, boolean bossAlive, ObjectAction quickLeave) {
        // Combat inside the Brutus instance never uses the global walker or
        // minimap. Cancel a travel route only when one actually exists; repeatedly
        // clearing an already-null route floods WebWalkLog and can obscure the
        // Brutus diagnostics.
        clearWalkerRouteIfActive("brutus-instance-combat");
        initialBankCheckPending = false;
        altarRestorePending = false;

        if (!hasConfiguredFood()) {
            disableManagedCombatPrayers();
            quickLeave(quickLeave, "Configured food depleted");
            return;
        }

        // Healing is an emergency action and must remain available during combat
        // animations. A food click must not suppress a simultaneously detected
        // special, so special movement is still evaluated in the same script cycle.
        boolean healingHandled = eatIfNeeded();

        // Keep processing an already active special even if the NPC cache briefly
        // drops Brutus during a Charge transform/movement transition. Otherwise the
        // completed rear-tile dodge is discarded before the Attack interaction can
        // be confirmed.
        if ((bossAlive
                || activeSpecial != SpecialAttack.NONE
                || pendingSpecial != SpecialAttack.NONE)
                && handleSpecialAttack(brutus)) {
            return;
        }

        if (healingHandled) {
            return;
        }

        // Equipment determines the combat mode. Make sure Magic has the configured
        // elemental staff + autocast spell selected, and merge any recovered
        // matching ranged ammunition back into the equipped ammo stack before an
        // attack/re-attack can be issued.
        if (maintainCombatEquipmentAndStyle(bossAlive)) {
            return;
        }

        // Movement and food cancel the current combat interaction. Reacquire the
        // boss before lower-priority maintenance such as potions, prayers or styles.
        if (bossAlive && combatReacquirePending) {
            attackBrutus(brutus);
            return;
        }

        // A newly spawned Brutus re-enables the configured prayers before potion or
        // equipment maintenance can consume another cycle.
        if (bossAlive && !prayersSuppressedUntilRespawn && manageCombatPrayers()) {
            return;
        }

        if (bossAlive && useStatBoostingPotionIfNeeded()) {
            return;
        }

        if (equipMooletaFromInventory()) {
            return;
        }

        if (balanceCombatStyle()) {
            return;
        }

        if (!bossAlive) {
            resetSpecialDetection();
        }

        if (!bossAlive && disableManagedCombatPrayers()) {
            return;
        }

        // Matching arrows/bolts are supply recovery and are handled independently
        // of the generic Loot all setting.
        if (!bossAlive && recoverTrackedRangedAmmo()) {
            return;
        }

        if (!bossAlive && buryBones()) {
            return;
        }

        if (!bossAlive && lootOneItem()) {
            return;
        }

        if (!bossAlive) {
            if (config.bankWhenFull() && Rs2Inventory.isFull()) {
                quickLeave(quickLeave, "Inventory full");
                return;
            }
            setState(KspMadCowState.WAITING_FOR_RESPAWN, "Waiting for Brutus to respawn");
            return;
        }

        attackBrutus(brutus);
    }

    private void handleOutsideInstance() {
        disableManagedCombatPrayers();

        // Prayer restoration and its follow-up teleport are transactional. Once the
        // altar has been clicked, no banking, Cowbell charging, equipment or style
        // branch may interrupt the transition.
        if (altarTeleportPending) {
            travelWithCowbell(true);
            if (!travelRequired || cowbellTravelIssued) {
                altarTeleportPending = false;
            }
            return;
        }

        if (altarRestorePending && restorePrayerBeforeTravel()) {
            return;
        }

        if (needsBanking()) {
            handleBanking();
            return;
        }

        if (!travelRequired) {
            ObjectAction entry = findObjectAction(PEN_ENTRY_ACTIONS);
            if (entry == null) {
                setState(KspMadCowState.TRAVELLING, cowbellTravelIssued
                        ? "Cowbell used; waiting for Brutus pen"
                        : "At Brutus pen; waiting for entry action");
                return;
            }

            cowbellTravelIssued = false;
            enterInstance(entry);
            return;
        }

        if (chargeCowbellIfPossible()) {
            return;
        }

        if (equipMooletaFromInventory()) {
            return;
        }

        if (balanceCombatStyle()) {
            return;
        }

        if (restorePrayerBeforeTravel()) {
            return;
        }

        travelWithCowbell();
    }

    private void handleLeavingInstance(ObjectAction quickLeave) {
        disableManagedCombatPrayers();
        resetSpecialDetection();

        if (clientInstanceDetected || quickLeave != null) {
            instanceConfirmed = true;
            setState(KspMadCowState.LEAVING_INSTANCE,
                    quickLeaveClickIssued ? "Waiting until outside the instance" : "Using Quick-escape gate");

            if (!quickLeaveClickIssued && quickLeave != null && playerReadyForAction()) {
                if (quickLeave.object.click(quickLeave.action)) {
                    quickLeaveClickIssued = true;
                }
            }
            return;
        }

        // Only now may banking/pathfinding begin.
        leavingInstance = false;
        quickLeaveClickIssued = false;
        instanceConfirmed = false;
        clientInstanceDetected = false;
        initialBankCheckPending = true;
        travelRequired = false;
        cowbellTravelIssued = false;
        lastPenEntryAction = "";
        lastPenEntryAttemptTick = Integer.MIN_VALUE;
        killArmed = false;
        setState(KspMadCowState.BANKING, "Outside instance; preparing to bank");
    }

    private boolean needsBanking() {
        return initialBankCheckPending
                || !hasRequiredFoodAmount()
                || !hasCowbell()
                || (config.bankWhenFull() && Rs2Inventory.isFull());
    }

    private void handleBanking() {
        setState(KspMadCowState.BANKING, "Preparing supplies at bank");

        if (!Rs2Bank.isOpen()) {
            bankActionPending = false;
            if (!Rs2Player.isMoving()) {
                if (Rs2Bank.walkToBank()) {
                    Rs2Bank.openBank();
                }
            }
            return;
        }

        if (awaitingBankInventoryChange()) {
            return;
        }

        Rs2ItemModel unwanted = Rs2Inventory.all().stream()
                .filter(item -> !keepDuringBanking(item))
                .findFirst()
                .orElse(null);
        if (unwanted != null) {
            setState(KspMadCowState.BANKING, "Depositing " + unwanted.getName());
            if (Rs2Bank.depositAll(unwanted.getId())) {
                final int unwantedId = unwanted.getId();
                markBankAction("deposit " + unwanted.getName(), () -> !Rs2Inventory.hasItem(unwantedId));
            }
            return;
        }

        if (!hasCowbell()) {
            if (Rs2Bank.hasBankItem(COWBELL_CHARGED_ID, 1)) {
                setState(KspMadCowState.BANKING, "Withdrawing charged Cowbell");
                if (Rs2Bank.withdrawOne(COWBELL_CHARGED_ID)) {
                    markBankAction("withdraw Cowbell", this::hasCowbell);
                }
                return;
            }
            if (Rs2Bank.hasBankItem(COWBELL_EMPTY_ID, 1)) {
                setState(KspMadCowState.BANKING, "Withdrawing empty Cowbell");
                if (Rs2Bank.withdrawOne(COWBELL_EMPTY_ID)) {
                    markBankAction("withdraw Cowbell", this::hasCowbell);
                }
                return;
            }
            supplyFailure("No Cowbell amulet was found in inventory, equipment, or bank");
            return;
        }

        int foodTarget = Math.max(1, config.foodAmount());
        int foodCount = getConfiguredFoodQuantity();
        if (foodCount < foodTarget) {
            setState(KspMadCowState.BANKING,
                    "Withdrawing " + config.food().getName() + " (" + foodCount + "/" + foodTarget + ")");
            if (!Rs2Bank.hasBankItem(config.food().getId(), foodTarget - foodCount)) {
                supplyFailure("The bank does not contain enough " + config.food().getName()
                        + " (inventory " + foodCount + "/" + foodTarget + ")");
                return;
            }
            if (Rs2Bank.withdrawDeficit(config.food().getId(), foodTarget)) {
                markBankAction("withdraw food", this::hasRequiredFoodAmount);
            }
            return;
        }

        // Magic supply setup is driven by the detected equipped weapon type.
        // Every rune type used by the selected spell is withdrawn with Withdraw-All.
        // The matching elemental staff is still equipped for the selected spell, but
        // banking no longer uses a configured cast-count target.
        if (handleMagicBanking()) {
            return;
        }

        int magicAirReserve = minimumMagicRuneReserve(Runes.AIR);
        int airTarget = Math.max(1, config.airRunesToCarry());
        int airCount = Rs2Inventory.itemQuantity(AIR_RUNE_ID);
        int chargeableAirCount = Math.max(0, airCount - magicAirReserve);
        if (chargeableAirCount < airTarget) {
            if (Rs2Bank.hasBankItem(AIR_RUNE_ID, 1)) {
                final int previousAirCount = airCount;
                setState(KspMadCowState.BANKING,
                        "Withdrawing all available air runes (chargeable "
                                + chargeableAirCount + "/" + airTarget + ")");
                visibleDebug("Bank", "Withdraw-All Air runes requested inventory="
                        + airCount + " magicReserve=" + magicAirReserve
                        + " chargeable=" + chargeableAirCount
                        + " configuredTarget=" + airTarget);
                if (Rs2Bank.withdrawAll(AIR_RUNE_ID)) {
                    markBankAction("withdraw all air runes",
                            () -> Rs2Inventory.itemQuantity(AIR_RUNE_ID) > previousAirCount);
                } else {
                    visibleDebug("Bank", "Withdraw-All Air runes was not issued");
                }
                return;
            }

            if (chargeableAirCount == 0 && Rs2Inventory.hasItem(COWBELL_EMPTY_ID)) {
                visibleDebug("Bank", "Empty Cowbell cannot be charged: no Air runes are available beyond magic reserve="
                        + magicAirReserve);
                supplyFailure("The Cowbell is empty and no spare air runes are available for charging");
                return;
            }
        }

        if (config.equipMooleta()
                && combatMode == CombatMode.MELEE
                && !Rs2Equipment.isWearing(MOOLETA_ID)
                && !Rs2Inventory.hasItem(MOOLETA_ID)
                && Rs2Bank.hasBankItem(MOOLETA_ID, 1)) {
            setState(KspMadCowState.BANKING, "Withdrawing Mooleta");
            if (Rs2Bank.withdrawOne(MOOLETA_ID)) {
                markBankAction("withdraw Mooleta", () -> Rs2Inventory.hasItem(MOOLETA_ID) || Rs2Equipment.isWearing(MOOLETA_ID));
            }
            return;
        }

        String potionToWithdraw = findPotionToWithdrawFromBank();
        if (potionToWithdraw != null) {
            setState(KspMadCowState.BANKING, "Withdrawing " + potionToWithdraw);
            if (Rs2Bank.withdrawOne(potionToWithdraw)) {
                String[] expectedPotions = potionPrioritiesForMode(combatMode);
                markBankAction("withdraw potion", () -> hasAnyInventoryPotion(expectedPotions));
            }
            return;
        }

        initialBankCheckPending = false;
        suppliesErrorShown = false;
        travelRequired = true;
        cowbellTravelIssued = false;
        lastPenEntryAction = "";
        lastPenEntryAttemptTick = Integer.MIN_VALUE;
        instanceConfirmed = false;
        clientInstanceDetected = false;
        leavingInstance = false;
        quickLeaveClickIssued = false;
        Rs2Bank.closeBank();
    }

    private boolean handleMagicBanking() {
        if (combatMode != CombatMode.MAGIC || config == null || config.combatSpell() == null) {
            return false;
        }

        KspMadCowSpell selection = config.combatSpell();
        int staffId = selection.getStaffItemId();

        if (!Rs2Equipment.isWearing(staffId) && !Rs2Inventory.hasItem(staffId)) {
            if (!Rs2Bank.hasBankItem(staffId, 1)) {
                supplyFailure("Missing elemental staff for " + selection + " (item " + staffId + ")");
                return true;
            }

            setState(KspMadCowState.BANKING, "Withdrawing staff for " + selection);
            visibleDebug("Magic", "withdrawing elemental staff id=" + staffId
                    + " spell=" + selection);
            if (Rs2Bank.withdrawOne(staffId)) {
                markBankAction("withdraw " + selection + " staff",
                        () -> Rs2Inventory.hasItem(staffId) || Rs2Equipment.isWearing(staffId));
            }
            return true;
        }

        boolean matchingElementalStaffEquipped = Rs2Equipment.isWearing(staffId);

        for (Map.Entry<Runes, Integer> entry : selection.getRequiredRunes().entrySet()) {
            Runes rune = entry.getKey();
            Integer perCast = entry.getValue();
            if (rune == null || perCast == null || perCast <= 0) {
                continue;
            }

            // An equipped elemental staff provides an unlimited supply of its
            // matching elemental rune. Do not withdraw that rune from the bank.
            // This is intentionally based on equipment, not merely having the staff
            // in inventory, so the bank behavior reflects the character's active gear.
            if (matchingElementalStaffEquipped && rune == selection.getStaffRune()) {
                visibleDebug("Magic", "skipping " + rune
                        + " rune withdrawal; matching staff is equipped id=" + staffId
                        + " spell=" + selection);
                continue;
            }

            int runeId = rune.getItemId();
            int current = Rs2Inventory.itemQuantity(runeId);

            // The selected spell owns the rune list. Whenever the bank still has
            // one of those rune types, take the complete stack instead of targeting
            // an arbitrary number of casts. Stackable runes do not consume extra
            // slots as their quantity grows.
            if (Rs2Bank.hasBankItem(runeId, 1)) {
                final int previousQuantity = current;
                setState(KspMadCowState.BANKING,
                        "Withdrawing all " + rune.name().toLowerCase(Locale.ROOT)
                                + " runes for " + selection);
                visibleDebug("Magic", "withdraw-all rune=" + rune
                        + " inventoryBefore=" + current
                        + " spell=" + selection);
                if (Rs2Bank.withdrawAll(runeId)) {
                    markBankAction("withdraw all " + rune.name().toLowerCase(Locale.ROOT) + " runes",
                            () -> Rs2Inventory.itemQuantity(runeId) > previousQuantity
                                    || !Rs2Bank.hasBankItem(runeId, 1));
                }
                return true;
            }

            // Once the bank stack is exhausted, make sure there are at least enough
            // runes for one cast unless the equipped elemental staff supplies that
            // rune. This reports an actual missing-supply problem without reintroducing
            // a configurable cast-count target.
            if (!(matchingElementalStaffEquipped && rune == selection.getStaffRune())
                    && current < perCast) {
                supplyFailure("Not enough " + rune.name().toLowerCase(Locale.ROOT)
                        + " runes to cast " + selection
                        + " (need " + perCast + ", inventory " + current + ")");
                return true;
            }
        }

        return false;
    }

    private int minimumMagicRuneReserve(Runes rune) {
        if (combatMode != CombatMode.MAGIC
                || config == null
                || config.combatSpell() == null
                || rune == null) {
            return 0;
        }

        KspMadCowSpell selection = config.combatSpell();
        if (rune == selection.getStaffRune()) {
            return 0;
        }

        Integer perCast = selection.getRequiredRunes().get(rune);
        return perCast == null || perCast <= 0 ? 0 : perCast;
    }

    private boolean isConfiguredMagicSupply(int itemId) {
        if (combatMode != CombatMode.MAGIC || config == null || config.combatSpell() == null) {
            return false;
        }

        KspMadCowSpell selection = config.combatSpell();
        if (itemId == selection.getStaffItemId()) {
            return true;
        }

        for (Runes rune : selection.getRequiredRunes().keySet()) {
            if (rune != null && rune.getItemId() == itemId) {
                return true;
            }
        }
        return false;
    }

    private int chargeableCowbellAirRunes() {
        int total = Rs2Inventory.itemQuantity(AIR_RUNE_ID);
        int reserve = minimumMagicRuneReserve(Runes.AIR);
        return Math.max(0, total - reserve);
    }

    private boolean keepDuringBanking(Rs2ItemModel item) {
        if (item == null) {
            return false;
        }
        int id = item.getId();
        if (id == config.food().getId()
                || id == AIR_RUNE_ID
                || id == COWBELL_EMPTY_ID
                || id == COWBELL_CHARGED_ID
                || id == MOOLETA_ID
                || id == trackedRangedAmmoId
                || isConfiguredMagicSupply(id)) {
            return true;
        }
        return config.useStatBoostingPotions() && isKnownStatPotion(item.getName());
    }

    private void markBankAction(String description, BooleanSupplier completionCondition) {
        bankActionPending = true;
        bankActionInventoryRevision = inventoryRevision.get();
        bankActionDescription = description;
        bankActionComplete = completionCondition;
    }

    private boolean awaitingBankInventoryChange() {
        if (!bankActionPending) {
            return false;
        }
        boolean completed = bankActionComplete != null && bankActionComplete.getAsBoolean();
        if (completed || inventoryRevision.get() != bankActionInventoryRevision) {
            bankActionPending = false;
            bankActionDescription = "";
            bankActionComplete = null;
            return false;
        }
        setState(KspMadCowState.BANKING, "Waiting for inventory update: " + bankActionDescription);
        return true;
    }

    public void onInventoryChanged() {
        inventoryRevision.incrementAndGet();
    }

    public void onGraphicsObjectCreated(GraphicsObject graphicsObject) {
        if (!running
                || graphicsObject == null
                || !STOMP_GRAPHICS.contains(graphicsObject.getId())
                || graphicsObject.getLocation() == null) {
            return;
        }

        try {
            WorldPoint tile = WorldPoint.fromLocal(Microbot.getClient(), graphicsObject.getLocation());
            if (tile == null) {
                return;
            }

            int gameTick = Microbot.getClient().getTickCount();
            stompImpactTileTicks.put(tile, gameTick);

            // These graphics are impact-time evidence. They are intentionally not
            // allowed to start or delay a dodge because movement initiated here
            // would occur after the dangerous tiles have already resolved.
            visibleDebug("Stomp", "impact graphic id=" + graphicsObject.getId()
                    + " tile=" + tile
                    + " tick=" + gameTick
                    + " active=" + activeSpecial
                    + " selectedSafeTile=" + specialDodgeTarget);
            if (activeSpecial == SpecialAttack.STOMP
                    && specialDodgeTarget != null
                    && specialDodgeTarget.equals(tile)) {
                visibleDebug("Stomp", "WARNING impact appeared on predicted safe tile " + tile);
            }
        } catch (Exception ex) {
            log.debug("Unable to record Brutus Stomp graphic tile", ex);
        }
    }

    private void pruneStompImpactTiles() {
        int gameTick = currentGameTick();
        if (gameTick == Integer.MIN_VALUE || stompImpactTileTicks.isEmpty()) {
            return;
        }

        boolean removed = stompImpactTileTicks.entrySet().removeIf(entry -> {
            int observedTick = entry.getValue();
            return observedTick > gameTick
                    || gameTick - observedTick > STOMP_GRAPHICS_LIFETIME_TICKS;
        });
        if (removed) {
        }
    }

    private Set<WorldPoint> currentStompImpactTiles() {
        pruneStompImpactTiles();
        if (stompImpactTileTicks.isEmpty()) {
            return Set.of();
        }

        int minimumTick = stompActivationTick == Integer.MIN_VALUE
                ? Integer.MIN_VALUE
                : stompActivationTick - 1;
        Set<WorldPoint> result = new HashSet<>();
        stompImpactTileTicks.forEach((tile, observedTick) -> {
            if (observedTick >= minimumTick) {
                result.add(tile);
            }
        });
        return result;
    }

    private boolean handleCowbellChargeAmountInput() {
        String prompt = visibleChatboxFullInputText();
        boolean cowbellPromptVisible = isCowbellChargeAmountPrompt(prompt);

        if (!cowbellPromptVisible) {
            // Once the server applies the submitted quantity, inventoryRevision
            // changes because air runes and/or the Cowbell stack changed.
            if (cowbellChargeInputPending
                    && inventoryRevision.get() != cowbellChargeAttemptRevision) {
                clearCowbellChargeInputState();
                cowbellChargeAttemptRevision = -1L;
                cowbellChargeAttemptTick = Integer.MIN_VALUE;
            }
            return false;
        }

        int availableAirRunes = chargeableCowbellAirRunes();
        int amount = Math.min(100, Math.max(0, availableAirRunes));
        if (amount <= 0) {
            setState(KspMadCowState.CHARGING_COWBELL,
                    "Cowbell charge prompt open, but no air runes remain");
            return true;
        }

        // Recover safely if the plugin was started while this prompt was already
        // open, or if the prompt appeared after the normal state timed out.
        if (!cowbellChargeInputPending) {
            cowbellChargeInputPending = true;
            cowbellChargeAttemptRevision = inventoryRevision.get();
            cowbellChargeAttemptTick = currentGameTick();
            cowbellChargeInputAmount = amount;
        } else if (cowbellChargeInputAmount <= 0) {
            cowbellChargeInputAmount = amount;
        }

        if (!cowbellChargeInputSubmitted) {
            cowbellChargeInputAmount = Math.min(100, Math.min(cowbellChargeInputAmount, amount));
            setState(KspMadCowState.CHARGING_COWBELL,
                    "Entering " + cowbellChargeInputAmount + " Cowbell charge"
                            + (cowbellChargeInputAmount == 1 ? "" : "s"));

            // RuneScape's amount box accepts ordinary typed digits followed by
            // Enter. Rs2Keyboard dispatches those key events directly to the game
            // canvas, so this works without stealing desktop focus.
            Rs2Keyboard.typeString(Integer.toString(cowbellChargeInputAmount));
            Rs2Keyboard.enter();
            cowbellChargeInputSubmitted = true;
            cowbellChargeInputSubmitTick = currentGameTick();
        } else {
            setState(KspMadCowState.CHARGING_COWBELL,
                    "Waiting for " + cowbellChargeInputAmount + " Cowbell charges to apply");
        }

        return true;
    }

    private String visibleChatboxFullInputText() {
        return Microbot.getClientThread().runOnClientThreadOptional(() -> {
            StringBuilder visibleText = new StringBuilder();
            WidgetInfo[] candidates = {
                    WidgetInfo.CHATBOX_FULL_INPUT,
                    WidgetInfo.CHATBOX_TITLE,
                    WidgetInfo.CHATBOX_INPUT
            };

            for (WidgetInfo candidate : candidates) {
                var widget = Microbot.getClient().getWidget(candidate);
                if (widget == null || widget.isHidden() || widget.getText() == null) {
                    continue;
                }
                if (visibleText.length() > 0) {
                    visibleText.append(' ');
                }
                visibleText.append(widget.getText());
            }

            return visibleText.length() == 0 ? null : visibleText.toString();
        }).orElse(null);
    }

    private boolean isCowbellChargeAmountPrompt(String text) {
        if (text == null || text.isBlank()) {
            return false;
        }

        String normalized = text
                .replaceAll("<[^>]*>", " ")
                .replace('&', ' ')
                .replaceAll("\\s+", " ")
                .trim()
                .toLowerCase(Locale.ROOT);
        return normalized.contains("how many charges do you want to apply");
    }

    private void clearCowbellChargeInputState() {
        cowbellChargeInputPending = false;
        cowbellChargeInputSubmitted = false;
        cowbellChargeInputAmount = 0;
        cowbellChargeInputSubmitTick = Integer.MIN_VALUE;
    }

    private boolean chargeCowbellIfPossible() {
        long revision = inventoryRevision.get();
        int gameTick = currentGameTick();

        if (cowbellChargeInputPending) {
            if (revision != cowbellChargeAttemptRevision) {
                clearCowbellChargeInputState();
                cowbellChargeAttemptRevision = -1L;
                cowbellChargeAttemptTick = Integer.MIN_VALUE;
            } else {
                int anchorTick = cowbellChargeInputSubmitted
                        ? cowbellChargeInputSubmitTick
                        : cowbellChargeAttemptTick;
                int waitTicks = cowbellChargeInputSubmitted ? 5 : 4;

                if (gameTick == Integer.MIN_VALUE
                        || anchorTick == Integer.MIN_VALUE
                        || gameTick <= anchorTick + waitTicks) {
                    setState(KspMadCowState.CHARGING_COWBELL,
                            cowbellChargeInputSubmitted
                                    ? "Waiting for Cowbell charges to apply"
                                    : "Waiting for Cowbell amount prompt");
                    return true;
                }

                // No prompt and no inventory update means the Cowbell rejected the
                // use (normally because it is already full). Do not repeatedly use
                // the same unchanged rune stack.
                clearCowbellChargeInputState();
                return false;
            }
        }

        int airRunes = chargeableCowbellAirRunes();
        if (airRunes <= 0) {
            cowbellChargeAttemptRevision = -1L;
            cowbellChargeAttemptTick = Integer.MIN_VALUE;
            clearCowbellChargeInputState();
            return false;
        }

        if (Rs2Equipment.isWearing(COWBELL_EMPTY_ID)
                || Rs2Equipment.isWearing(COWBELL_CHARGED_ID)) {
            if (!playerReadyForAction()) {
                setState(KspMadCowState.CHARGING_COWBELL, "Waiting to remove Cowbell for charging");
                return true;
            }

            int equippedCowbellId = Rs2Equipment.isWearing(COWBELL_CHARGED_ID)
                    ? COWBELL_CHARGED_ID
                    : COWBELL_EMPTY_ID;
            setState(KspMadCowState.CHARGING_COWBELL,
                    "Removing Cowbell to add " + airRunes + " air rune" + (airRunes == 1 ? "" : "s"));
            Rs2Equipment.unEquip(equippedCowbellId);
            return true;
        }

        int cowbellId = Rs2Inventory.hasItem(COWBELL_CHARGED_ID)
                ? COWBELL_CHARGED_ID
                : Rs2Inventory.hasItem(COWBELL_EMPTY_ID)
                ? COWBELL_EMPTY_ID
                : -1;
        if (cowbellId == -1) {
            return false;
        }

        if (!playerReadyForAction()) {
            setState(KspMadCowState.CHARGING_COWBELL, "Waiting to charge Cowbell");
            return true;
        }

        int amountToApply = Math.min(100, airRunes);
        setState(KspMadCowState.CHARGING_COWBELL,
                "Opening Cowbell amount prompt for " + amountToApply + " charge"
                        + (amountToApply == 1 ? "" : "s"));
        Rs2Inventory.combine(AIR_RUNE_ID, cowbellId);
        cowbellChargeAttemptRevision = revision;
        cowbellChargeAttemptTick = gameTick;
        cowbellChargeInputPending = true;
        cowbellChargeInputSubmitted = false;
        cowbellChargeInputAmount = amountToApply;
        cowbellChargeInputSubmitTick = Integer.MIN_VALUE;
        return true;
    }

    private void travelWithCowbell() {
        travelWithCowbell(false);
    }

    private void travelWithCowbell(boolean bypassAnimationWait) {
        if (!travelRequired || instanceConfirmed || clientInstanceDetected || leavingInstance) {
            return;
        }

        if (!Rs2Inventory.hasItem(COWBELL_CHARGED_ID)
                && !Rs2Equipment.isWearing(COWBELL_CHARGED_ID)) {
            initialBankCheckPending = true;
            return;
        }

        // After Pray-at, Prayer points changing is the authoritative completion
        // signal. Do not wait for the remaining altar animation before teleporting.
        if (!bypassAnimationWait && !playerReadyForAction()) {
            setState(KspMadCowState.TRAVELLING, "Waiting to use Cowbell");
            return;
        }

        setState(KspMadCowState.TRAVELLING,
                bypassAnimationWait
                        ? "Prayer restored; immediately using Cowbell"
                        : "Using Cowbell: " + COWBELL_TRAVEL_ACTION);
        boolean travelled = interactInventoryFirstAvailable(COWBELL_CHARGED_ID, COWBELL_TRAVEL_ACTION);
        if (!travelled && Rs2Equipment.isWearing(COWBELL_CHARGED_ID)) {
            travelled = Rs2Equipment.interact(COWBELL_CHARGED_ID, COWBELL_TRAVEL_ACTION);
        }

        if (travelled) {
            travelRequired = false;
            cowbellTravelIssued = true;
            lastPenEntryAction = "";
            lastPenEntryAttemptTick = Integer.MIN_VALUE;
        } else {
            setState(KspMadCowState.ERROR, "Hardcoded Cowbell action was not available: " + COWBELL_TRAVEL_ACTION);
        }
    }

    private void enterInstance(ObjectAction entry) {
        int gameTick = currentGameTick();
        boolean sameActionAsLastAttempt = entry.action.equalsIgnoreCase(lastPenEntryAction);

        if (sameActionAsLastAttempt && lastPenEntryAttemptTick != Integer.MIN_VALUE) {
            int ticksSinceAttempt = gameTick == Integer.MIN_VALUE
                    ? PEN_ENTRY_RETRY_TICKS
                    : Math.max(0, gameTick - lastPenEntryAttemptTick);
            if (ticksSinceAttempt < PEN_ENTRY_RETRY_TICKS) {
                setState(KspMadCowState.ENTERING_INSTANCE,
                        "Waiting to retry pen gate (" + (PEN_ENTRY_RETRY_TICKS - ticksSinceAttempt) + " tick"
                                + (PEN_ENTRY_RETRY_TICKS - ticksSinceAttempt == 1 ? "" : "s") + ")");
                return;
            }

            // The previous gate interaction did not move us into the instance.
            // Only retry once the player is idle so we do not interrupt movement,
            // an animation, or the successful transition itself.
            if (!playerReadyForAction()) {
                setState(KspMadCowState.ENTERING_INSTANCE, "Gate retry ready; waiting for player to become idle");
                return;
            }

            setState(KspMadCowState.ENTERING_INSTANCE, "Retrying pen gate: " + entry.action);
        } else {
            setState(KspMadCowState.ENTERING_INSTANCE, "Pen action: " + entry.action);
            if (!playerReadyForAction()) {
                return;
            }
        }

        if (entry.object.click(entry.action)) {
            lastPenEntryAction = entry.action;
            lastPenEntryAttemptTick = gameTick;
            travelRequired = false;
        }
    }

    private boolean handleEntryDialogue() {
        if (!running || config == null || !config.autoConfirmEntry()) {
            return false;
        }
        if (travelRequired && !cowbellTravelIssued && lastPenEntryAction.isEmpty()) {
            return false;
        }

        if (Rs2Dialogue.hasDialogueOption("Yes and don't ask again")) {
            setState(KspMadCowState.ENTERING_INSTANCE, "Confirming Brutus entry");
            return Rs2Dialogue.clickOption("Yes and don't ask again");
        }

        if (Rs2Dialogue.hasDialogueOption("Yes")) {
            setState(KspMadCowState.ENTERING_INSTANCE, "Confirming Brutus entry");
            return Rs2Dialogue.clickOption("Yes");
        }

        if (Rs2Dialogue.hasContinue()) {
            setState(KspMadCowState.ENTERING_INSTANCE, "Continuing Brutus entry dialogue");
            Rs2Dialogue.clickContinue();
            return true;
        }

        return false;
    }

    private boolean eatIfNeeded() {
        int hpPercent = hitpointsPercent();
        int threshold = config.eatAtPercent();
        if (hpPercent > threshold) {
            clearHealActionState();
            return false;
        }

        int debugTick = currentGameTick();
        if (debugTick != lastHealDebugTick) {
            lastHealDebugTick = debugTick;
            visibleDebug("Heal", "threshold reached hp=" + hpPercent
                    + "% threshold=" + threshold
                    + "% pending=" + healActionPending
                    + " foodId=" + config.food().getId()
                    + " foodQty=" + getConfiguredFoodQuantity());
        }

        // Eating must not depend on the generic idle predicate. OSRS permits food
        // use while the player is in combat, so attack animations cannot suppress
        // healing at or below the configured threshold.
        if (healActionPending) {
            boolean inventoryChanged = inventoryRevision.get() != healActionInventoryRevision;
            boolean hpChanged = hpPercent > healActionHpBefore;
            int gameTick = currentGameTick();
            boolean confirmationWindowExpired = gameTick != Integer.MIN_VALUE
                    && healActionIssuedTick != Integer.MIN_VALUE
                    && gameTick > healActionIssuedTick + 1;

            if (inventoryChanged || hpChanged) {
                visibleDebug("Heal", "food confirmed inventoryChanged=" + inventoryChanged
                        + " hpChanged=" + hpChanged
                        + " hpBefore=" + healActionHpBefore
                        + "% hpNow=" + hpPercent + "%");
                clearHealActionState();
                // If still below the threshold, allow another food on the next loop.
                return true;
            }

            if (!confirmationWindowExpired) {
                setState(KspMadCowState.HEALING,
                        "Waiting for food confirmation at " + hpPercent + "% HP");
                return true;
            }

            visibleDebug("Heal", "food click not confirmed; retrying");
            // The click was not accepted; retry after clearing only this attempt.
            clearHealActionState();
        }

        Rs2ItemModel food = Rs2Inventory.get(config.food().getId());
        if (food == null) {
            visibleDebug("Heal", "no configured food found hp=" + hpPercent
                    + "% foodId=" + config.food().getId());
            return false;
        }

        setState(KspMadCowState.HEALING,
                "Eating " + config.food().getName() + " at " + hpPercent + "% HP");
        long revisionBefore = inventoryRevision.get();
        boolean clicked = Rs2Inventory.interact(food, "Eat");
        if (!clicked) {
            clicked = Rs2Inventory.interact(food, "eat");
        }
        visibleDebug("Heal", "eat issued=" + clicked
                + " item=" + food.getName()
                + " hp=" + hpPercent
                + "% threshold=" + threshold + "%");
        if (clicked) {
            healActionPending = true;
            healActionInventoryRevision = revisionBefore;
            healActionHpBefore = hpPercent;
            healActionIssuedTick = currentGameTick();
            combatReacquirePending = true;
            return true;
        }
        return false;
    }

    private void clearHealActionState() {
        healActionPending = false;
        healActionInventoryRevision = -1L;
        healActionHpBefore = -1;
        healActionIssuedTick = Integer.MIN_VALUE;
    }

    private boolean restorePrayerBeforeTravel() {
        if (!config.restorePrayerBeforeTravel()) {
            altarRestorePending = false;
            altarInteractionIssued = false;
            altarPrayerPointsBeforeInteraction = -1;
            return false;
        }

        int prayerPoints = getCurrentPrayerPointsSafe();

        // Prayer points changing after Pray-at is the authoritative completion
        // signal. Immediately transition to Cowbell teleport without waiting for
        // the altar animation or generic player-idle state.
        if (altarInteractionIssued
                && altarPrayerPointsBeforeInteraction >= 0
                && prayerPoints != altarPrayerPointsBeforeInteraction) {
            visibleDebug("Altar", "Prayer changed after Pray-at before="
                    + altarPrayerPointsBeforeInteraction + " now=" + prayerPoints
                    + "; teleporting immediately");
            altarRestorePending = false;
            altarInteractionIssued = false;
            altarPrayerPointsBeforeInteraction = -1;
            altarTeleportPending = true;
            clearWalkerRouteIfActive("brutus-altar-prayer-restored");
            setState(KspMadCowState.TRAVELLING,
                    "Prayer points changed; immediately teleporting with Cowbell");
            travelWithCowbell(true);
            if (!travelRequired || cowbellTravelIssued) {
                altarTeleportPending = false;
            }
            return true;
        }

        if (!altarRestorePending && prayerPoints > 0) {
            altarInteractionIssued = false;
            altarPrayerPointsBeforeInteraction = -1;
            return false;
        }

        altarRestorePending = true;
        WorldPoint playerLocation = Rs2Player.getWorldLocation();
        if (playerLocation == null || !ALTAR_AREA.contains(playerLocation)) {
            setState(KspMadCowState.RESTORING_PRAYER, "Walking to Lumbridge altar");
            if (!Rs2Player.isMoving()) {
                Rs2Walker.walkTo(ALTAR_LOCATION, 3);
            }
            return true;
        }

        // The long route is complete as soon as the player enters interaction range.
        if (Rs2Walker.getCurrentTarget() != null) {
            visibleDebug("Altar", "entered altar area at " + playerLocation
                    + "; cancelling walker target " + Rs2Walker.getCurrentTarget());
        }
        clearWalkerRouteIfActive("brutus-entered-altar-area");

        Rs2TileObjectModel altar = Microbot.getRs2TileObjectCache().query()
                .withId(ALTAR_ID)
                .nearestOnClientThread();
        if (altar == null) {
            setState(KspMadCowState.RESTORING_PRAYER, "Waiting for nearby altar ID 409");
            return true;
        }

        setState(KspMadCowState.RESTORING_PRAYER,
                altarInteractionIssued
                        ? "Waiting for Prayer points to change"
                        : "Directly praying at Lumbridge altar");
        if (!altarInteractionIssued) {
            int before = prayerPoints;
            boolean clicked = altar.click("Pray-at");
            log.debug("[Altar] Pray-at interaction issued={} prayerBefore={} altarId={} player={}",
                    clicked, before, ALTAR_ID, playerLocation);
            if (clicked) {
                altarPrayerPointsBeforeInteraction = before;
                altarInteractionIssued = true;
            }
        }
        return true;
    }

    private boolean manageCombatPrayers() {
        if (!config.useCombatPrayers()) {
            return disableManagedCombatPrayers();
        }
        if (getCurrentPrayerPointsSafe() <= 0) {
            activePrayerSummary = "None (0 points)";
            return false;
        }

        Rs2PrayerEnum[] desired = desiredPrayersFor(combatMode, getRealPrayerLevelSafe());
        List<Rs2PrayerEnum> desiredList = Arrays.asList(desired);

        // Change one prayer per cycle so the state is always observable and deterministic.
        for (Rs2PrayerEnum prayer : MANAGED_COMBAT_PRAYERS) {
            if (Rs2Prayer.isPrayerActive(prayer) && !desiredList.contains(prayer)) {
                setState(KspMadCowState.MANAGING_PRAYERS, "Disabling " + prayer.getName());
                Rs2Prayer.toggle(prayer, false);
                refreshActivePrayerSummary();
                return true;
            }
        }
        for (Rs2PrayerEnum prayer : desired) {
            if (!Rs2Prayer.isPrayerActive(prayer)) {
                setState(KspMadCowState.MANAGING_PRAYERS, "Activating " + prayer.getName());
                Rs2Prayer.toggle(prayer, true);
                refreshActivePrayerSummary();
                return true;
            }
        }

        refreshActivePrayerSummary();
        return false;
    }

    private Rs2PrayerEnum[] desiredPrayersFor(CombatMode mode, int prayerLevel) {
        List<Rs2PrayerEnum> desired = new ArrayList<>();

        // Brutus attacks with melee while the player is in normal combat range, so
        // Protect from Melee is kept alongside the best standard offensive prayer
        // available for the detected gear style.
        if (prayerLevel >= Rs2PrayerEnum.PROTECT_MELEE.getLevel()) {
            desired.add(Rs2PrayerEnum.PROTECT_MELEE);
        }

        switch (mode) {
            case RANGED:
                if (prayerLevel >= Rs2PrayerEnum.EAGLE_EYE.getLevel()) {
                    desired.add(Rs2PrayerEnum.EAGLE_EYE);
                } else if (prayerLevel >= Rs2PrayerEnum.HAWK_EYE.getLevel()) {
                    desired.add(Rs2PrayerEnum.HAWK_EYE);
                } else if (prayerLevel >= Rs2PrayerEnum.SHARP_EYE.getLevel()) {
                    desired.add(Rs2PrayerEnum.SHARP_EYE);
                }
                break;

            case MAGIC:
                if (prayerLevel >= Rs2PrayerEnum.MYSTIC_MIGHT.getLevel()) {
                    desired.add(Rs2PrayerEnum.MYSTIC_MIGHT);
                } else if (prayerLevel >= Rs2PrayerEnum.MYSTIC_LORE.getLevel()) {
                    desired.add(Rs2PrayerEnum.MYSTIC_LORE);
                } else if (prayerLevel >= Rs2PrayerEnum.MYSTIC_WILL.getLevel()) {
                    desired.add(Rs2PrayerEnum.MYSTIC_WILL);
                }
                break;

            case MELEE:
            default:
                if (prayerLevel >= Rs2PrayerEnum.ULTIMATE_STRENGTH.getLevel()) {
                    desired.add(Rs2PrayerEnum.ULTIMATE_STRENGTH);
                } else if (prayerLevel >= Rs2PrayerEnum.SUPERHUMAN_STRENGTH.getLevel()) {
                    desired.add(Rs2PrayerEnum.SUPERHUMAN_STRENGTH);
                }

                if (prayerLevel >= Rs2PrayerEnum.INCREDIBLE_REFLEXES.getLevel()) {
                    desired.add(Rs2PrayerEnum.INCREDIBLE_REFLEXES);
                } else if (prayerLevel >= Rs2PrayerEnum.IMPROVED_REFLEXES.getLevel()) {
                    desired.add(Rs2PrayerEnum.IMPROVED_REFLEXES);
                } else if (prayerLevel >= Rs2PrayerEnum.CLARITY_THOUGHT.getLevel()) {
                    desired.add(Rs2PrayerEnum.CLARITY_THOUGHT);
                }
                break;
        }

        return desired.toArray(new Rs2PrayerEnum[0]);
    }

    private boolean disableManagedCombatPrayers() {
        boolean changed = false;
        for (Rs2PrayerEnum prayer : MANAGED_COMBAT_PRAYERS) {
            if (Rs2Prayer.isPrayerActive(prayer)) {
                Rs2Prayer.toggle(prayer, false);
                changed = true;
            }
        }
        refreshActivePrayerSummary();
        return changed;
    }

    private void refreshActivePrayerSummary() {
        List<String> active = new ArrayList<>();
        for (Rs2PrayerEnum prayer : MANAGED_COMBAT_PRAYERS) {
            if (Rs2Prayer.isPrayerActive(prayer)) {
                active.add(prayer.getName());
            }
        }
        activePrayerSummary = active.isEmpty() ? "None" : String.join(" + ", active);
    }

    private CombatMode detectCombatMode() {
        Rs2ItemModel weapon = Rs2Equipment.get(EquipmentInventorySlot.WEAPON);
        Rs2ItemModel ammo = Rs2Equipment.get(EquipmentInventorySlot.AMMO);

        refreshTrackedRangedAmmo(ammo);

        CombatMode detected = detectCombatModeFromEquipmentNames(weapon, ammo);
        if (detected == null) {
            detected = detectCombatModeFromEquippedWeaponCategory();
        }
        if (detected == null) {
            detected = CombatMode.MELEE;
        }

        int weaponId = weapon == null ? -1 : weapon.getId();
        int ammoId = ammo == null ? -1 : ammo.getId();
        if (weaponId != lastCombatGearWeaponId
                || ammoId != lastCombatGearAmmoId
                || detected != lastLoggedCombatMode) {
            visibleDebug("CombatStyle", "gear detection weapon="
                    + describeEquipmentItem(weapon)
                    + " ammo=" + describeEquipmentItem(ammo)
                    + " weaponCategory=" + Microbot.getVarbitValue(VarbitID.COMBAT_WEAPON_CATEGORY)
                    + " detected=" + detected
                    + (detected == CombatMode.MAGIC && config != null
                    ? " configuredSpell=" + config.combatSpell()
                    : "")
                    + (trackedRangedAmmoId > 0
                    ? " trackedAmmo=" + trackedRangedAmmoName + "(" + trackedRangedAmmoId + ")"
                    : ""));
            lastCombatGearWeaponId = weaponId;
            lastCombatGearAmmoId = ammoId;
            lastLoggedCombatMode = detected;
        }

        return detected;
    }

    private CombatMode detectCombatModeFromEquippedWeaponCategory() {
        try {
            int weaponCategory = Microbot.getVarbitValue(VarbitID.COMBAT_WEAPON_CATEGORY);
            EnumComposition weaponStyles = Microbot.getEnum(EnumID.WEAPON_STYLES);
            if (weaponStyles == null) {
                return null;
            }

            int styleEnumId = weaponStyles.getIntValue(weaponCategory);
            EnumComposition styleEnum = Microbot.getEnum(styleEnumId);
            if (styleEnum == null || styleEnum.getIntVals() == null) {
                return null;
            }

            boolean ranged = false;
            boolean magic = false;
            for (int styleStructId : styleEnum.getIntVals()) {
                StructComposition styleStruct = Microbot.getStructComposition(styleStructId);
                if (styleStruct == null) {
                    continue;
                }

                String styleName = styleStruct.getStringValue(ParamID.ATTACK_STYLE_NAME);
                if (styleName == null) {
                    continue;
                }

                String normalized = styleName.toLowerCase(Locale.ROOT);
                if (normalized.contains("rapid")
                        || normalized.contains("longrange")
                        || normalized.contains("long range")
                        || normalized.contains("ranged")) {
                    ranged = true;
                }
                if (normalized.contains("spell")
                        || normalized.contains("cast")
                        || normalized.contains("magic")) {
                    magic = true;
                }
            }

            // Staves expose a Spell/Autocast combat option even if the currently
            // selected style happens to be Bash/Pound/Focus. That makes the
            // equipped weapon category a better mode signal than the selected
            // attack-style button.
            if (magic) {
                return CombatMode.MAGIC;
            }
            if (ranged) {
                return CombatMode.RANGED;
            }
            return CombatMode.MELEE;
        } catch (Exception ex) {
            log.debug("Unable to detect combat mode from equipped weapon category", ex);
            return null;
        }
    }

    private CombatMode detectCombatModeFromEquipmentNames(
            Rs2ItemModel weapon, Rs2ItemModel ammo) {
        String weaponName = weapon == null || weapon.getName() == null
                ? ""
                : weapon.getName().toLowerCase(Locale.ROOT);

        if (weaponName.contains("bow")
                || weaponName.contains("crossbow")
                || weaponName.contains("ballista")
                || weaponName.contains("blowpipe")
                || weaponName.contains("chinchompa")
                || weaponName.contains("javelin")
                || weaponName.contains("throwing knife")
                || weaponName.contains("thrownaxe")) {
            return CombatMode.RANGED;
        }

        if (weaponName.contains("staff")
                || weaponName.contains("wand")
                || weaponName.contains("sceptre")
                || weaponName.contains("scepter")
                || weaponName.contains("trident")
                || weaponName.contains("sanguinesti")
                || weaponName.contains("tumeken")) {
            return CombatMode.MAGIC;
        }

        if (weaponName.isEmpty() && isRangedAmmo(ammo)) {
            return CombatMode.RANGED;
        }

        return weapon == null ? CombatMode.MELEE : null;
    }

    private void refreshTrackedRangedAmmo(Rs2ItemModel ammo) {
        if (!isRangedAmmo(ammo)) {
            return;
        }

        if (trackedRangedAmmoId != ammo.getId()) {
            trackedRangedAmmoId = ammo.getId();
            trackedRangedAmmoName = ammo.getName() == null ? "ammo" : ammo.getName();
            visibleDebug("Ranged", "tracking equipped ammunition "
                    + trackedRangedAmmoName + " id=" + trackedRangedAmmoId
                    + " quantity=" + ammo.getQuantity());
        } else if (ammo.getName() != null) {
            trackedRangedAmmoName = ammo.getName();
        }
    }

    private boolean isRangedAmmo(Rs2ItemModel item) {
        if (item == null || item.getName() == null) {
            return false;
        }
        String name = item.getName().toLowerCase(Locale.ROOT);
        return name.contains("arrow") || name.contains("bolt");
    }

    private String describeEquipmentItem(Rs2ItemModel item) {
        if (item == null) {
            return "none";
        }
        return (item.getName() == null ? "item" : item.getName())
                + "(" + item.getId() + ")";
    }

    private boolean maintainCombatEquipmentAndStyle(boolean bossAlive) {
        combatMode = detectCombatMode();

        if (combatMode == CombatMode.RANGED) {
            trainingSkill = Skill.RANGED;
            return equipTrackedRangedAmmoFromInventory();
        }

        if (combatMode != CombatMode.MAGIC) {
            return false;
        }

        trainingSkill = Skill.MAGIC;
        KspMadCowSpell selection = config.combatSpell();
        if (selection == null) {
            setState(KspMadCowState.ERROR, "No Magic spell configured");
            return true;
        }

        int realMagic = readLevels(Skill.MAGIC)[1];
        int requiredMagic = selection.getCombatSpell().getRequiredLevel();
        if (realMagic < requiredMagic) {
            setState(KspMadCowState.ERROR,
                    "Magic level " + realMagic + " is too low for " + selection
                            + " (requires " + requiredMagic + ")");
            visibleDebug("Magic", "autocast blocked: level=" + realMagic
                    + " required=" + requiredMagic
                    + " spell=" + selection);
            return true;
        }

        int staffId = selection.getStaffItemId();
        if (!Rs2Equipment.isWearing(staffId)) {
            if (!Rs2Inventory.hasItem(staffId)) {
                setState(KspMadCowState.ERROR,
                        "Configured elemental staff is missing for " + selection);
                visibleDebug("Magic", "required staff missing id=" + staffId
                        + " spell=" + selection);
                return true;
            }

            if (!playerReadyForAction()) {
                setState(KspMadCowState.FIGHTING,
                        "Waiting to equip elemental staff for " + selection);
                return true;
            }

            setState(KspMadCowState.FIGHTING,
                    "Equipping elemental staff for " + selection);
            boolean equipped = Rs2Inventory.interact(staffId, "Wield");
            visibleDebug("Magic", "staff equip issued=" + equipped
                    + " staffId=" + staffId
                    + " spell=" + selection);
            combatReacquirePending = true;
            return true;
        }

        if (!bossAlive) {
            return false;
        }

        if (Rs2Magic.getCurrentAutoCastSpell() == selection.getCombatSpell()) {
            return false;
        }

        if (!playerReadyForAction()) {
            setState(KspMadCowState.FIGHTING,
                    "Waiting to select autocast " + selection);
            return true;
        }

        setState(KspMadCowState.FIGHTING, "Selecting autocast " + selection);
        boolean selected = Rs2Combat.setAutoCastSpell(selection.getCombatSpell(), false);
        visibleDebug("Magic", "autocast selection issued=" + selected
                + " spell=" + selection
                + " current=" + Rs2Magic.getCurrentAutoCastSpell());
        combatReacquirePending = true;
        return true;
    }

    private boolean equipTrackedRangedAmmoFromInventory() {
        if (combatMode != CombatMode.RANGED
                || trackedRangedAmmoId <= 0
                || !Rs2Inventory.hasItem(trackedRangedAmmoId)) {
            return false;
        }

        if (!playerReadyForAction()) {
            setState(KspMadCowState.FIGHTING,
                    "Waiting to equip recovered " + trackedRangedAmmoName);
            return true;
        }

        int gameTick = currentGameTick();
        if (gameTick != Integer.MIN_VALUE && gameTick == lastRangedAmmoEquipTick) {
            return true;
        }
        lastRangedAmmoEquipTick = gameTick;

        int quantity = Rs2Inventory.itemQuantity(trackedRangedAmmoId);
        setState(KspMadCowState.FIGHTING,
                "Equipping recovered " + trackedRangedAmmoName);
        boolean issued = Rs2Inventory.interact(trackedRangedAmmoId, "Wield");
        if (!issued) {
            issued = Rs2Inventory.interact(trackedRangedAmmoId, "Equip");
        }
        visibleDebug("Ranged", "ammo equip issued=" + issued
                + " ammo=" + trackedRangedAmmoName
                + " id=" + trackedRangedAmmoId
                + " inventoryQuantity=" + quantity);
        if (issued) {
            combatReacquirePending = true;
        }
        return issued;
    }

    private boolean recoverTrackedRangedAmmo() {
        if (combatMode != CombatMode.RANGED || trackedRangedAmmoId <= 0) {
            return false;
        }

        if (equipTrackedRangedAmmoFromInventory()) {
            return true;
        }

        if (!playerReadyForAction()) {
            return false;
        }

        Rs2TileItemModel ammo = Microbot.getRs2TileItemCache().query()
                .where(item -> item.isLootAble() && item.getId() == trackedRangedAmmoId)
                .within(config.lootRadius())
                .nearestOnClientThread();
        if (ammo == null) {
            return false;
        }

        boolean fits = !Rs2Inventory.isFull()
                || (ammo.isStackable() && Rs2Inventory.hasItem(trackedRangedAmmoId));
        if (!fits) {
            visibleDebug("Ranged", "matching ammo on ground but inventory is full ammo="
                    + trackedRangedAmmoName + " id=" + trackedRangedAmmoId);
            return false;
        }

        setState(KspMadCowState.LOOTING,
                "Recovering " + trackedRangedAmmoName);
        boolean pickedUp = ammo.pickup();
        visibleDebug("Ranged", "ammo pickup issued=" + pickedUp
                + " ammo=" + trackedRangedAmmoName
                + " id=" + trackedRangedAmmoId);
        return pickedUp;
    }

    private boolean equipMooletaFromInventory() {
        combatMode = detectCombatMode();
        if (!config.equipMooleta()
                || combatMode != CombatMode.MELEE
                || Rs2Equipment.isWearing(MOOLETA_ID)
                || !Rs2Inventory.hasItem(MOOLETA_ID)) {
            return false;
        }
        if (!playerReadyForAction()) {
            setState(KspMadCowState.EQUIPPING_MOOLETA, "Waiting to equip Mooleta");
            return true;
        }
        setState(KspMadCowState.EQUIPPING_MOOLETA, "Equipping Mooleta");
        return Rs2Inventory.interact(MOOLETA_ID, "Wield");
    }

    private boolean balanceCombatStyle() {
        combatMode = detectCombatMode();
        if (combatMode == CombatMode.RANGED) {
            trainingSkill = Skill.RANGED;
            return false;
        }
        if (combatMode == CombatMode.MAGIC) {
            trainingSkill = Skill.MAGIC;
            return false;
        }
        if (!config.balanceCombatStats()) {
            return false;
        }

        Skill targetSkill = lowestMeleeSkill();
        trainingSkill = targetSkill;
        int targetStyleIndex = findStyleIndex(targetSkill);
        if (targetStyleIndex < 0 || targetStyleIndex >= MELEE_STYLE_WIDGETS.length) {
            return false;
        }

        int currentStyleIndex = Microbot.getVarbitPlayerValue(VarPlayerID.COM_MODE);
        if (currentStyleIndex == targetStyleIndex) {
            return false;
        }
        if (!playerReadyForAction()) {
            return false;
        }

        setMessage("Switching style to train " + targetSkill.getName());
        Rs2Tab.switchTo(InterfaceTab.COMBAT);
        return Rs2Combat.setAttackStyle(MELEE_STYLE_WIDGETS[targetStyleIndex]);
    }

    private Skill lowestMeleeSkill() {
        int[] levels = readLevels(Skill.ATTACK, Skill.STRENGTH, Skill.DEFENCE);
        int attack = levels[1];
        int strength = levels[3];
        int defence = levels[5];
        if (strength < attack && strength <= defence) {
            return Skill.STRENGTH;
        }
        if (defence < attack && defence < strength) {
            return Skill.DEFENCE;
        }
        return Skill.ATTACK;
    }

    private int findStyleIndex(Skill targetSkill) {
        try {
            int weaponCategory = Microbot.getVarbitValue(VarbitID.COMBAT_WEAPON_CATEGORY);
            EnumComposition weaponStyles = Microbot.getEnum(EnumID.WEAPON_STYLES);
            if (weaponStyles == null) {
                return -1;
            }
            int styleEnumId = weaponStyles.getIntValue(weaponCategory);
            EnumComposition styleEnum = Microbot.getEnum(styleEnumId);
            if (styleEnum == null || styleEnum.getIntVals() == null) {
                return -1;
            }

            int controlledFallback = -1;
            int[] styleStructs = styleEnum.getIntVals();
            for (int index = 0; index < Math.min(styleStructs.length, MELEE_STYLE_WIDGETS.length); index++) {
                StructComposition styleStruct = Microbot.getStructComposition(styleStructs[index]);
                if (styleStruct == null) {
                    continue;
                }
                String styleName = styleStruct.getStringValue(ParamID.ATTACK_STYLE_NAME);
                if (styleName == null) {
                    continue;
                }
                String normalized = styleName.toLowerCase(Locale.ROOT);
                if (normalized.equals("controlled")) {
                    controlledFallback = index;
                }
                if (targetSkill == Skill.ATTACK && normalized.equals("accurate")) {
                    return index;
                }
                if (targetSkill == Skill.STRENGTH && normalized.equals("aggressive")) {
                    return index;
                }
                if (targetSkill == Skill.DEFENCE && normalized.equals("defensive")) {
                    return index;
                }
            }
            return controlledFallback;
        } catch (Exception ex) {
            log.debug("Unable to resolve attack style", ex);
            return -1;
        }
    }

    private boolean handleSpecialAttack(Rs2NpcModel brutus) {
        if (!config.dodgeSpecials()) {
            clearSpecialAvoidance();
            return false;
        }

        if (brutus != null && brutus.getNpc() != null) {
            // Read the authoritative growl/snort label before classifying the
            // animation from the same client cycle. This prevents an animation
            // event from activating the opposite special before its cue is seen.
            pollBrutusOverheadCue(brutus);
            pollBrutusAnimation(brutus);
        }

        SpecialSignal signal = consumePendingSpecial();
        if (signal.attack != SpecialAttack.NONE) {
            activateSpecial(signal, brutus);
        }

        if (activeSpecial == SpecialAttack.NONE) {
            return false;
        }

        if (specialDodgeCandidates.isEmpty()) {
            specialDodgeCandidates = activeSpecial == SpecialAttack.CHARGE
                    ? findChargeDodgeCandidates(brutus, null, -1)
                    : findStompDodgeCandidates(brutus, null, -1);
            specialCandidateIndex = 0;
            specialDodgeTarget = specialDodgeCandidates.isEmpty() ? null : specialDodgeCandidates.get(0);
        }

        // Treat arrival on any precomputed safe candidate as completion. A local
        // scene click can resolve onto another equivalent side/rear candidate even
        // when the originally selected tile is occupied for a client cycle.
        WorldPoint reachedCandidate = playerSpecialCandidate();
        if (reachedCandidate != null) {
            specialDodgeTarget = reachedCandidate;
            specialTargetReached = true;
            clearWalkerRouteIfActive("brutus-special-safe-tile");
            visibleDebug("Dodge", "safe tile reached special=" + activeSpecial
                    + " scenePlayer=" + getCombatScenePlayerLocation()
                    + " cachedPlayer=" + Rs2Player.getWorldLocation()
                    + " selected=" + reachedCandidate
                    + " candidates=" + specialDodgeCandidates);
        }

        if (specialTargetReached) {
            if (activeSpecial == SpecialAttack.CHARGE) {
                handleChargeSafeTileReattack();
            } else {
                handleStompSafeTileReattack();
            }
            return true;
        }

        String target = specialDodgeTarget == null
                ? "searching"
                : specialDodgeTarget.getX() + ", " + specialDodgeTarget.getY() + ", " + specialDodgeTarget.getPlane();
        setState(KspMadCowState.DODGING,
                (activeSpecial == SpecialAttack.CHARGE
                        ? "Dodging Charge behind Brutus @ "
                        : "Dodging Stomp immediately to side/rear @ ") + target);

        if (specialDodgeTarget == null) {
            return true;
        }

        // Issue one immediate local dodge click. After that, never click the same
        // destination simply because the player is momentarily not moving. A retry
        // is allowed only after the player has shown no tile progress for multiple
        // game ticks, and the retry rotates to another safe candidate when possible.
        int gameTick = currentGameTick();
        updateSpecialMovementProgress(gameTick);
        if (shouldIssueSpecialMovement(gameTick)) {
            lastSpecialMovementTick = gameTick;
            issueSpecialMovement();
        }
        return true;
    }

    private void handleChargeSafeTileReattack() {
        handleSpecialSafeTileReattack("Charge");
    }

    private void handleStompSafeTileReattack() {
        handleSpecialSafeTileReattack("Stomp");
    }

    private void handleSpecialSafeTileReattack(String specialName) {
        setState(KspMadCowState.FIGHTING,
                specialName + " safe tile reached; re-attacking Brutus by NPC ID");

        if (isPlayerTargetingBrutusId()) {
            visibleDebug("Combat", specialName + " re-attack confirmed; target is Brutus");
            finishSpecialAvoidance(false);
            return;
        }

        combatReacquirePending = true;
        // The requested recovery rule is animation-based: once the player is not
        // animating, invoke Brutus again. Do not additionally block on movement.
        if (isPlayerCurrentlyAnimating()) {
            logCombatBlockedOnce(specialName + " re-attack", "player animating");
            return;
        }

        int gameTick = currentGameTick();
        if (gameTick != Integer.MIN_VALUE && gameTick == lastSpecialReattackTick) {
            return;
        }
        lastSpecialReattackTick = gameTick;

        Rs2NpcModel idBrutus = findBrutus();
        if (idBrutus == null && isBrutusIdNpc(lastKnownBrutusNpc)) {
            idBrutus = new Rs2NpcModel(lastKnownBrutusNpc);
        }
        if (idBrutus == null || idBrutus.getNpc() == null
                || !isBrutusIdNpc(idBrutus.getNpc())) {
            visibleDebug("Combat", specialName + " re-attack skipped; Brutus IDs "
                    + BRUTUS_ID + "/" + BRUTUS_ALT_ID + " not found");
            return;
        }

        boolean issued = invokeBrutusAttackById(idBrutus, specialName + " re-attack");
        visibleDebug("Combat", specialName + " re-attack issued=" + issued
                + " tick=" + gameTick
                + " npcId=" + idBrutus.getId()
                + " npcIndex=" + idBrutus.getIndex()
                + " player=" + Rs2Player.getWorldLocation()
                + " safeTile=" + specialDodgeTarget);
        if (issued) {
            // Release the special state immediately after the Attack menu action.
            // Normal combat owns confirmation/retry from here, while the shared
            // game-tick gate prevents an immediate duplicate click.
            lastCombatAttackTick = gameTick;
            finishSpecialAvoidance(true);
        }
    }

    private void pollBrutusAnimation(Rs2NpcModel brutus) {
        BrutusAnimationSnapshot animation = Microbot.getClientThread().runOnClientThreadOptional(() -> {
            NPC npc = brutus.getNpc();
            if (npc == null) {
                return BrutusAnimationSnapshot.NONE;
            }
            int orientation = npc.getOrientation();
            if (orientation < 0) {
                orientation = npc.getCurrentOrientation();
            }
            return new BrutusAnimationSnapshot(
                    npc.getAnimation(),
                    npc.getAnimationFrame(),
                    npc.getWorldArea(),
                    orientation
            );
        }).orElse(BrutusAnimationSnapshot.NONE);

        currentBrutusAnimation = animation.animation;
        currentBrutusAnimationFrame = animation.frame;
        boolean newCycle = currentBrutusAnimation != lastObservedBrutusAnimation
                || (currentBrutusAnimation == lastObservedBrutusAnimation
                && currentBrutusAnimationFrame >= 0
                && lastObservedBrutusFrame >= 0
                && currentBrutusAnimationFrame < lastObservedBrutusFrame);

        if (newCycle) {
            queueSpecialFromAnimation(
                    currentBrutusAnimation,
                    animation.area,
                    animation.orientation
            );
        }
        lastObservedBrutusAnimation = currentBrutusAnimation;
        lastObservedBrutusFrame = currentBrutusAnimationFrame;

        if (chargeSequenceLatched
                && chargeSequenceAnimationObserved
                && !CHARGE_ANIMATIONS.contains(currentBrutusAnimation)
                && activeSpecial != SpecialAttack.CHARGE) {
            chargeSequenceLatched = false;
            chargeSequenceAnimationObserved = false;
        }

        if (stompSequenceLatched
                && !STOMP_ANIMATIONS.contains(currentBrutusAnimation)
                && activeSpecial != SpecialAttack.STOMP
                && !"stomp".equals(lastObservedOverheadCue)) {
            stompSequenceLatched = false;
        }
    }

    private void pollBrutusOverheadCue(Rs2NpcModel brutus) {
        String overheadText = Microbot.getClientThread().runOnClientThreadOptional(
                () -> brutus.getNpc() == null ? null : brutus.getNpc().getOverheadText()
        ).orElse(null);
        String cue = normalizeSpecialCue(overheadText);
        if (!cue.equals(lastObservedOverheadCue)) {
            String previousCue = lastObservedOverheadCue;
            lastObservedOverheadCue = cue;
            visibleDebug("Special", "overhead changed previous='" + previousCue
                    + "' current='" + cue
                    + "' raw='" + overheadText
                    + "' animation=" + currentBrutusAnimation
                    + " active=" + activeSpecial
                    + " pending=" + pendingSpecial);
            if ("charge".equals(cue)) {
                queueSpecialFromCue(
                        SpecialAttack.CHARGE,
                        getNpcArea(brutus),
                        getNpcOrientation(brutus)
                );
            } else if ("stomp".equals(cue)) {
                queueSpecialFromCue(
                        SpecialAttack.STOMP,
                        getNpcArea(brutus),
                        getNpcOrientation(brutus)
                );
            }
        }
    }

    public void onBrutusOverheadText(Actor actor, String overheadText) {
        if (!running || !isBrutusActor(actor)) {
            return;
        }
        lastKnownBrutusNpc = (NPC) actor;
        String cue = normalizeSpecialCue(overheadText);
        lastObservedOverheadCue = cue;
        int orientation = actor.getOrientation();
        if (orientation < 0) {
            orientation = actor.getCurrentOrientation();
        }
        visibleDebug("Special", "overhead event cue='" + cue
                + "' raw='" + overheadText
                + "' animation=" + actor.getAnimation()
                + " frame=" + actor.getAnimationFrame()
                + " area=" + actor.getWorldArea()
                + " orientation=" + orientation
                + " active=" + activeSpecial
                + " pending=" + pendingSpecial);
        if ("charge".equals(cue)) {
            queueSpecialFromCue(SpecialAttack.CHARGE, actor.getWorldArea(), orientation);
        } else if ("stomp".equals(cue)) {
            queueSpecialFromCue(SpecialAttack.STOMP, actor.getWorldArea(), orientation);
        }
    }

    public void onBrutusAnimationChanged(Actor actor) {
        if (!running || !isBrutusActor(actor)) {
            return;
        }
        lastKnownBrutusNpc = (NPC) actor;
        int animation = actor.getAnimation();
        currentBrutusAnimation = animation;
        currentBrutusAnimationFrame = actor.getAnimationFrame();
        int orientation = actor.getOrientation();
        if (orientation < 0) {
            orientation = actor.getCurrentOrientation();
        }
        visibleDebug("Animation", "event id=" + animation
                + " frame=" + currentBrutusAnimationFrame
                + " area=" + actor.getWorldArea()
                + " orientation=" + orientation
                + " active=" + activeSpecial
                + " pending=" + pendingSpecial
                + " cue=" + cuePrimedAttack);
        queueSpecialFromAnimation(animation, actor.getWorldArea(), orientation);
    }

    /**
     * Brutus's overhead cues are the authoritative special labels:
     * growls = Charge and snorts = Stomp/Slam. A Stomp must begin immediately,
     * so either cue queues its dodge immediately with the current live
     * footprint/orientation. Matching animations may refine geometry, but can
     * never select or replace the special type.
     */
    private synchronized void queueSpecialFromCue(
            SpecialAttack attack,
            WorldArea area,
            int orientation
    ) {
        if (attack == SpecialAttack.NONE) {
            return;
        }

        int gameTick = currentGameTick();
        visibleDebug("Special", "cue=" + attack
                + " tick=" + gameTick
                + " animation=" + currentBrutusAnimation
                + " area=" + area
                + " orientation=" + orientation
                + " active=" + activeSpecial
                + " pending=" + pendingSpecial);

        // Overhead text is the authoritative special label. Never let an
        // animation classification turn Charge into Stomp or Stomp into Charge.
        if (activeSpecial != SpecialAttack.NONE) {
            if (activeSpecial == attack) {
                int activeAge = gameTick == Integer.MIN_VALUE
                        || activeSpecialStartedTick == Integer.MIN_VALUE
                        ? 0
                        : gameTick - activeSpecialStartedTick;
                if (activeAge <= 1) {
                    visibleDebug("Special", "same-tick duplicate cue=" + attack
                            + " ignored activeAge=" + activeAge);
                    return;
                }

                // A repeated overhead cue after the original cue disappeared is a
                // new special cycle. Restart stale movement/re-attack state instead
                // of remaining permanently latched to a failed dodge.
                visibleDebug("Special", "new " + attack
                        + " cue restarts stale active special ageTicks=" + activeAge
                        + " oldTarget=" + specialDodgeTarget
                        + " scenePlayer=" + getCombatScenePlayerLocation());
                clearSpecialAvoidance();
                combatReacquirePending = true;
            } else {

            // Brutus cannot begin two different specials simultaneously. A new,
            // authoritative opposite overhead cue means the old dodge state is
            // stale. Replace it immediately instead of continuing to treat the
            // new Charge as Stomp (or vice versa).
            visibleDebug("Special", "authoritative cue=" + attack
                    + " supersedes stale active=" + activeSpecial
                    + " scenePlayer=" + getCombatScenePlayerLocation()
                    + " cachedPlayer=" + Rs2Player.getWorldLocation()
                    + " oldTarget=" + specialDodgeTarget);
            clearSpecialAvoidance();
            combatReacquirePending = true;
            }
        }

        if (pendingSpecial != SpecialAttack.NONE && pendingSpecial != attack) {
            visibleDebug("Special", "replacing stale pending=" + pendingSpecial
                    + " with authoritative cue=" + attack);
        }

        pendingSpecial = attack;
        pendingSpecialFromAnimation = false;
        pendingSpecialAnimation = -1;
        pendingSpecialArea = area;
        pendingSpecialOrientation = orientation;
        cuePrimedAttack = attack;
        cuePrimedTick = gameTick;

        if (attack == SpecialAttack.CHARGE) {
            chargeSequenceLatched = true;
            chargeSequenceAnimationObserved = false;
            stompSequenceLatched = false;
        } else {
            stompSequenceLatched = true;
            chargeSequenceLatched = false;
            chargeSequenceAnimationObserved = false;
        }

        visibleDebug("Special", attack + " queued immediately from overhead cue");
    }

    private synchronized void queueSpecialFromAnimation(
            int animation,
            WorldArea area,
            int orientation
    ) {
        SpecialAttack classified = specialForAnimation(animation);
        if (classified == SpecialAttack.NONE) {
            return;
        }

        int gameTick = currentGameTick();
        visibleDebug("Animation", "id=" + animation
                + " classified=" + classified
                + " frame=" + currentBrutusAnimationFrame
                + " tick=" + gameTick
                + " active=" + activeSpecial
                + " pending=" + pendingSpecial
                + " cue=" + cuePrimedAttack);

        // Animations may refine geometry only after an overhead cue has already
        // selected the special. They are never allowed to create or change type.
        if (activeSpecial != SpecialAttack.NONE) {
            if (activeSpecial != classified) {
                visibleDebug("Animation", "ignored conflicting classification=" + classified
                        + " while active=" + activeSpecial);
                return;
            }
            specialAnimationObserved = true;
            if (classified == SpecialAttack.CHARGE) {
                chargeSequenceAnimationObserved = true;
            }
            if (!specialMovementAttempted && !specialTargetReached && area != null && orientation >= 0) {
                List<WorldPoint> refined = classified == SpecialAttack.CHARGE
                        ? findChargeDodgeCandidates(null, area, orientation)
                        : findStompDodgeCandidates(null, area, orientation);
                if (!refined.isEmpty()) {
                    specialDodgeCandidates = refined;
                    specialCandidateIndex = 0;
                    specialDodgeTarget = refined.get(0);
                    specialMovementTargetAttempts = 0;
                    visibleDebug("Dodge", "refined " + classified + " geometry from matching animation: "
                            + refined);
                }
            }
            return;
        }

        if (pendingSpecial == SpecialAttack.NONE) {
            visibleDebug("Animation", "ignored unprimed animation=" + animation
                    + "; waiting for growl/snort cue");
            return;
        }
        if (pendingSpecial != classified) {
            visibleDebug("Animation", "ignored classification=" + classified
                    + " because authoritative pending cue=" + pendingSpecial);
            return;
        }

        pendingSpecialFromAnimation = true;
        pendingSpecialAnimation = animation;
        if (area != null) {
            pendingSpecialArea = area;
        }
        if (orientation >= 0) {
            pendingSpecialOrientation = orientation;
        }
        specialAnimationObserved = true;
        if (classified == SpecialAttack.CHARGE) {
            chargeSequenceAnimationObserved = true;
        }
        visibleDebug("Animation", "matching animation enriched pending=" + pendingSpecial
                + " area=" + pendingSpecialArea
                + " orientation=" + pendingSpecialOrientation);
    }

    private synchronized SpecialSignal consumePendingSpecial() {
        if (pendingSpecial == SpecialAttack.NONE) {
            return SpecialSignal.NONE;
        }
        SpecialSignal signal = new SpecialSignal(
                pendingSpecial,
                pendingSpecialFromAnimation,
                pendingSpecialAnimation,
                pendingSpecialArea,
                pendingSpecialOrientation
        );
        pendingSpecial = SpecialAttack.NONE;
        pendingSpecialFromAnimation = false;
        pendingSpecialAnimation = -1;
        pendingSpecialArea = null;
        pendingSpecialOrientation = -1;
        return signal;
    }

    private void activateSpecial(SpecialSignal signal, Rs2NpcModel brutus) {
        if (signal.attack == SpecialAttack.NONE) {
            return;
        }
        if (activeSpecial != SpecialAttack.NONE) {
            if (activeSpecial == signal.attack && signal.fromAnimation) {
                specialAnimationObserved = true;
            } else if (activeSpecial != signal.attack) {
                visibleDebug("Special", "activation conflict ignored active=" + activeSpecial
                        + " incoming=" + signal.attack
                        + " animation=" + signal.animation
                        + " area=" + signal.area
                        + " orientation=" + signal.orientation);
            }
            return;
        }

        activeSpecial = signal.attack;
        specialAnimationObserved = signal.fromAnimation;
        specialMovementAttempted = false;
        lastSpecialMovementTick = Integer.MIN_VALUE;
        specialMovementIssueCount = 0;
        specialMovementTargetAttempts = 0;
        specialMovementLastProgressTick = currentGameTick();
        activeSpecialStartedTick = currentGameTick();
        specialMovementLastPlayerLocation = getCombatScenePlayerLocation();
        specialMovementIssuedTargets.clear();
        specialTargetReached = false;
        lastSpecialReattackTick = Integer.MIN_VALUE;
        stompReattackIssued = false;
        stompReattackIssuedTick = Integer.MIN_VALUE;
        stompActivationTick = signal.attack == SpecialAttack.STOMP
                ? currentGameTick()
                : Integer.MIN_VALUE;
        combatReacquirePending = true;
        // Stomp must move from the overhead/animation signal itself. The three
        // RuneLite Stomp graphics appear at impact time and are therefore used only
        // as post-event validation, never as a movement prerequisite.
        specialDodgeCandidates = signal.attack == SpecialAttack.CHARGE
                ? findChargeDodgeCandidates(brutus, signal.area, signal.orientation)
                : findStompDodgeCandidates(brutus, signal.area, signal.orientation);
        specialCandidateIndex = 0;
        specialDodgeTarget = specialDodgeCandidates.isEmpty() ? null : specialDodgeCandidates.get(0);
        visibleDebug("Special", "activated=" + signal.attack
                + " animation=" + signal.animation
                + " orientation=" + signal.orientation
                + " area=" + signal.area
                + " scenePlayer=" + getCombatScenePlayerLocation()
                + " cachedPlayer=" + Rs2Player.getWorldLocation()
                + " candidates=" + specialDodgeCandidates
                + " selected=" + specialDodgeTarget);
    }

    private void updateSpecialMovementProgress(int gameTick) {
        WorldPoint player = getCombatScenePlayerLocation();
        if (player == null) {
            return;
        }
        if (specialMovementLastPlayerLocation == null
                || !player.equals(specialMovementLastPlayerLocation)) {
            WorldPoint previous = specialMovementLastPlayerLocation;
            specialMovementLastPlayerLocation = player;
            specialMovementLastProgressTick = gameTick;
            visibleDebug("Dodge", "movement progress special=" + activeSpecial
                    + " from=" + previous
                    + " to=" + player
                    + " target=" + specialDodgeTarget
                    + " tick=" + gameTick);
        }
    }

    private boolean shouldIssueSpecialMovement(int gameTick) {
        if (specialDodgeTarget == null) {
            return false;
        }
        if (gameTick != Integer.MIN_VALUE && gameTick == lastSpecialMovementTick) {
            return false;
        }
        if (!specialMovementAttempted) {
            return true;
        }
        if (Rs2Player.isMoving()) {
            return false;
        }
        if (gameTick == Integer.MIN_VALUE || lastSpecialMovementTick == Integer.MIN_VALUE) {
            return false;
        }

        boolean stalled = gameTick - lastSpecialMovementTick >= SPECIAL_MOVEMENT_RETRY_STALL_TICKS
                && (specialMovementLastProgressTick == Integer.MIN_VALUE
                || gameTick - specialMovementLastProgressTick >= SPECIAL_MOVEMENT_RETRY_STALL_TICKS);
        if (!stalled) {
            return false;
        }

        if (specialMovementTargetAttempts >= SPECIAL_MOVEMENT_ATTEMPTS_PER_TARGET) {
            return selectNextSpecialCandidate();
        }
        return true;
    }

    private boolean hasUnattemptedSpecialCandidate() {
        return specialDodgeCandidates.size() > 1
                && specialCandidateIndex + 1 < specialDodgeCandidates.size();
    }

    private boolean selectNextSpecialCandidate() {
        if (!hasUnattemptedSpecialCandidate()) {
            visibleDebug("Dodge", "no fallback candidate remains for " + activeSpecial
                    + " target=" + specialDodgeTarget);
            return false;
        }
        specialCandidateIndex++;
        specialDodgeTarget = specialDodgeCandidates.get(specialCandidateIndex);
        specialMovementTargetAttempts = 0;
        specialMovementAttempted = false;
        specialMovementLastProgressTick = currentGameTick();
        specialMovementLastPlayerLocation = getCombatScenePlayerLocation();
        visibleDebug("Dodge", "switching " + activeSpecial + " fallback target to "
                + specialDodgeTarget);
        return true;
    }

    private void issueSpecialMovement() {
        if (specialDodgeTarget == null) {
            visibleDebug("Dodge", "no selected target for " + activeSpecial);
            return;
        }

        // Brutus combat movement must never use the minimap or global web walker.
        // Clear a surviving route once, then invoke WALK directly on the scene canvas.
        clearWalkerRouteIfActive("brutus-special-dodge");
        WorldPoint playerBefore = getCombatScenePlayerLocation();
        boolean issued = invokeLocalSceneWalk(specialDodgeTarget);
        specialMovementAttempted = true;
        specialMovementTargetAttempts++;
        specialMovementIssueCount++;
        specialMovementLastPlayerLocation = playerBefore;
        specialMovementLastProgressTick = currentGameTick();

        visibleDebug("Dodge", "special=" + activeSpecial
                + " directCanvasWalk=" + issued
                + " attempt=" + specialMovementTargetAttempts
                + " total=" + specialMovementIssueCount
                + " player=" + playerBefore
                + " target=" + specialDodgeTarget
                + " candidates=" + specialDodgeCandidates);

        if (!issued) {
            // A canvas conversion/click rejection will not improve by repeatedly
            // clicking the same tile. Try the other valid rear/behind candidate
            // immediately, while still never using the minimap.
            selectNextSpecialCandidate();
        }
    }

    private boolean invokeLocalSceneWalk(WorldPoint target) {
        if (target == null) {
            return false;
        }

        SceneWalkProjection projection = Microbot.getClientThread()
                .runOnClientThreadOptional(() -> projectCombatSceneTile(target))
                .orElse(SceneWalkProjection.NONE);
        Point canvasPoint = projection.canvasPoint;

        if (!projection.available()
                || canvasPoint.getX() < 0
                || canvasPoint.getY() < 0
                || canvasPoint.getX() >= Microbot.getClient().getCanvasWidth()
                || canvasPoint.getY() >= Microbot.getClient().getCanvasHeight()) {
            visibleDebug("Dodge", "scene-only walk rejected"
                    + " targetScene=" + target
                    + " local=" + projection.localPoint
                    + " canvas=" + canvasPoint
                    + " worldViewBase=" + projection.worldViewBase
                    + " scenePlayer=" + getCombatScenePlayerLocation()
                    + " cachedPlayer=" + Rs2Player.getWorldLocation()
                    + "; minimap fallback is disabled");
            return false;
        }

        try {
            NewMenuEntry entry = new NewMenuEntry()
                    .option("Walk here")
                    .target("")
                    .identifier(0)
                    .type(MenuAction.WALK)
                    .param0(canvasPoint.getX())
                    .param1(canvasPoint.getY())
                    .itemId(0);

            Microbot.doInvoke(entry, new Rectangle(
                    canvasPoint.getX(),
                    canvasPoint.getY(),
                    1,
                    1
            ));
            return true;
        } catch (Exception ex) {
            log.warn("[KSP Mad Cow][Dodge] Direct canvas WALK invoke failed for {}", target, ex);
            visibleDebug("Dodge", "direct canvas WALK exception="
                    + ex.getClass().getSimpleName()
                    + " targetScene=" + target
                    + " local=" + projection.localPoint
                    + " canvas=" + canvasPoint);
            return false;
        }
    }

    private SceneWalkProjection projectCombatSceneTile(WorldPoint target) {
        if (target == null || Microbot.getClient() == null) {
            return SceneWalkProjection.NONE;
        }

        Player player = Microbot.getClient().getLocalPlayer();
        NPC brutus = isBrutusIdNpc(lastKnownBrutusNpc) ? lastKnownBrutusNpc : null;
        var worldView = brutus != null && brutus.getWorldView() != null
                ? brutus.getWorldView()
                : player != null && player.getWorldView() != null
                ? player.getWorldView()
                : Microbot.getClient().getTopLevelWorldView();
        if (worldView == null) {
            return SceneWalkProjection.NONE;
        }

        // Actor#getWorldArea/GetWorldLocation use live scene coordinates inside
        // instances (for example 128xx,37xx). Rs2Player.getWorldLocation and
        // Rs2LocalPoint.fromWorldInstance use template coordinates (for example
        // 326x,329x). First resolve the live scene coordinate directly against the
        // actor's WorldView; only use the template conversion as a compatibility
        // fallback for non-scene callers.
        LocalPoint localPoint = LocalPoint.fromWorld(worldView, target);
        if (localPoint == null) {
            localPoint = Rs2LocalPoint.fromWorldInstance(target);
        }
        if (localPoint == null) {
            return new SceneWalkProjection(
                    null,
                    null,
                    new WorldPoint(worldView.getBaseX(), worldView.getBaseY(), worldView.getPlane())
            );
        }

        Point canvasPoint = Perspective.localToCanvas(
                Microbot.getClient(),
                localPoint,
                worldView.getPlane()
        );
        return new SceneWalkProjection(
                localPoint,
                canvasPoint,
                new WorldPoint(worldView.getBaseX(), worldView.getBaseY(), worldView.getPlane())
        );
    }

    private void finishSpecialAvoidance(boolean reacquirePending) {
        combatReacquirePending = reacquirePending;
        // A short dodge must not leave a stale destination in the global walker.
        clearWalkerRouteIfActive("brutus-special-finished");
        clearSpecialAvoidance();
    }

    private List<WorldPoint> findChargeDodgeCandidates(
            Rs2NpcModel brutus,
            WorldArea capturedArea,
            int capturedOrientation
    ) {
        WorldArea area = capturedArea != null ? capturedArea : getNpcArea(brutus);
        int orientation = capturedOrientation >= 0
                ? capturedOrientation
                : getNpcOrientation(brutus);

        if (area == null || orientation < 0) {
            return List.of();
        }

        int[] facing = orientationVector(orientation);
        int behindX = -facing[0];
        int behindY = -facing[1];
        if (behindX == 0 && behindY == 0) {
            return List.of();
        }

        int minX = area.getX();
        int maxX = area.getX() + area.getWidth() - 1;
        int minY = area.getY();
        int maxY = area.getY() + area.getHeight() - 1;

        List<WorldPoint> candidates = new ArrayList<>();

        if (behindX != 0 && behindY != 0) {
            // Diagonal facing: prefer the exact tile one step beyond the rear corner.
            // The two rear-edge neighbours remain one tile behind the footprint and
            // provide reachable fallbacks if the corner itself is blocked.
            int x = behindX < 0 ? minX - 1 : maxX + 1;
            int y = behindY < 0 ? minY - 1 : maxY + 1;
            int edgeX = behindX < 0 ? minX : maxX;
            int edgeY = behindY < 0 ? minY : maxY;
            candidates.add(new WorldPoint(x, y, area.getPlane()));
            candidates.add(new WorldPoint(x, edgeY, area.getPlane()));
            candidates.add(new WorldPoint(edgeX, y, area.getPlane()));
        } else if (behindX != 0) {
            // East/west facing: every candidate is exactly one tile beyond the rear edge.
            int x = behindX < 0 ? minX - 1 : maxX + 1;
            addRearEdgeCandidates(candidates, x, minY, maxY, true, area.getPlane());
        } else {
            // North/south facing: every candidate is exactly one tile beyond the rear edge.
            int y = behindY < 0 ? minY - 1 : maxY + 1;
            addRearEdgeCandidates(candidates, y, minX, maxX, false, area.getPlane());
        }

        return preferWalkableCandidates(candidates, area);
    }

    private void addRearEdgeCandidates(
            List<WorldPoint> candidates,
            int fixedCoordinate,
            int minimum,
            int maximum,
            boolean fixedX,
            int plane
    ) {
        int center = minimum + (maximum - minimum) / 2;
        if (fixedX) {
            candidates.add(new WorldPoint(fixedCoordinate, center, plane));
            for (int value = minimum; value <= maximum; value++) {
                candidates.add(new WorldPoint(fixedCoordinate, value, plane));
            }
        } else {
            candidates.add(new WorldPoint(center, fixedCoordinate, plane));
            for (int value = minimum; value <= maximum; value++) {
                candidates.add(new WorldPoint(value, fixedCoordinate, plane));
            }
        }
    }

    private int[] orientationVector(int orientation) {
        int normalized = ((orientation % 2048) + 2048) % 2048;
        int direction = ((normalized + 128) / 256) & 7;
        switch (direction) {
            case 0: return new int[]{0, -1};  // South
            case 1: return new int[]{-1, -1}; // South-west
            case 2: return new int[]{-1, 0};  // West
            case 3: return new int[]{-1, 1};  // North-west
            case 4: return new int[]{0, 1};   // North
            case 5: return new int[]{1, 1};   // North-east
            case 6: return new int[]{1, 0};   // East
            case 7: return new int[]{1, -1};  // South-east
            default: return new int[]{0, 0};
        }
    }

    private List<WorldPoint> findStompDodgeCandidates(
            Rs2NpcModel brutus,
            WorldArea capturedArea,
            int capturedOrientation
    ) {
        WorldPoint player = getCombatScenePlayerLocation();
        WorldArea area = capturedArea != null ? capturedArea : getNpcArea(brutus);
        int orientation = capturedOrientation >= 0
                ? capturedOrientation
                : getNpcOrientation(brutus);
        if (player == null || area == null || orientation < 0) {
            visibleDebug("Stomp", "cannot calculate rear corners player=" + player
                    + " area=" + area + " orientation=" + orientation);
            return List.of();
        }

        int[] facing = orientationVector(orientation);
        if (facing[0] == 0 && facing[1] == 0) {
            visibleDebug("Stomp", "invalid orientation=" + orientation);
            return List.of();
        }

        WorldPoint backLeft = stompRearCorner(area, facing, true);
        WorldPoint backRight = stompRearCorner(area, facing, false);
        boolean leftWalkable = backLeft != null && isCombatSceneWalkable(backLeft);
        boolean rightWalkable = backRight != null && isCombatSceneWalkable(backRight);

        List<WorldPoint> candidates = new ArrayList<>();
        if (leftWalkable && rightWalkable) {
            if (player.distanceTo2D(backLeft) <= player.distanceTo2D(backRight)) {
                candidates.add(backLeft);
                candidates.add(backRight);
            } else {
                candidates.add(backRight);
                candidates.add(backLeft);
            }
        } else if (leftWalkable) {
            candidates.add(backLeft);
        } else if (rightWalkable) {
            candidates.add(backRight);
        } else {
            // Collision data can lag on the first animation cycle. Preserve only the
            // two geometrically valid rear corners, ordered by distance; never fall
            // back to a front, centre-side, or arbitrary tile.
            if (backLeft != null && backRight != null
                    && player.distanceTo2D(backRight) < player.distanceTo2D(backLeft)) {
                candidates.add(backRight);
                candidates.add(backLeft);
            } else {
                if (backLeft != null) candidates.add(backLeft);
                if (backRight != null) candidates.add(backRight);
            }
        }

        // Impact graphics are damage-time observations only. They must never
        // remove, delay, or replace the animation/cue-time rear-corner choice.
        Set<WorldPoint> observedImpactTiles = currentStompImpactTiles();
        visibleDebug("Stomp", "orientation=" + orientation
                + " facing=(" + facing[0] + "," + facing[1] + ")"
                + " area=" + area
                + " player=" + player
                + " backLeft=" + backLeft + " walkable=" + leftWalkable
                + " backRight=" + backRight + " walkable=" + rightWalkable
                + " impacts=" + observedImpactTiles
                + " candidates=" + candidates);
        return candidates;
    }

    private WorldPoint stompRearCorner(WorldArea area, int[] facing, boolean leftSide) {
        int minX = area.getX();
        int maxX = area.getX() + area.getWidth() - 1;
        int minY = area.getY();
        int maxY = area.getY() + area.getHeight() - 1;
        int centerX = minX + (maxX - minX) / 2;
        int centerY = minY + (maxY - minY) / 2;

        int backX = -facing[0];
        int backY = -facing[1];
        int leftX = -facing[1];
        int leftY = facing[0];
        int sideX = leftSide ? leftX : -leftX;
        int sideY = leftSide ? leftY : -leftY;

        // Combine "back" with "left/right" relative to Brutus's facing. For
        // cardinal facing this produces the two tiles diagonally outside the rear
        // corners. For diagonal facing it produces the two tiles outside the rear
        // edges. Both are behind Brutus and never in the frontal Slam pattern.
        int relativeX = Integer.compare(backX + sideX, 0);
        int relativeY = Integer.compare(backY + sideY, 0);
        int xDistance = Math.max(1, area.getWidth() / 2 + 1);
        int yDistance = Math.max(1, area.getHeight() / 2 + 1);

        return new WorldPoint(
                centerX + relativeX * xDistance,
                centerY + relativeY * yDistance,
                area.getPlane()
        );
    }

    private List<WorldPoint> preferWalkableCandidates(
            List<WorldPoint> candidates,
            WorldArea excludedArea
    ) {
        List<WorldPoint> walkable = distinctCandidates(candidates, excludedArea, true);
        // Instance collision snapshots can briefly lag at the exact animation tick.
        // Keep the same geometric candidates as a fallback instead of cancelling the
        // dodge solely because the walkability cache was not ready yet.
        return walkable.isEmpty()
                ? distinctCandidates(candidates, excludedArea, false)
                : walkable;
    }

    private List<WorldPoint> distinctCandidates(List<WorldPoint> candidates, WorldArea excludedArea, boolean requireWalkable) {
        List<WorldPoint> result = new ArrayList<>();
        Set<WorldPoint> seen = new HashSet<>();
        for (WorldPoint candidate : candidates) {
            if (candidate == null || !seen.add(candidate)) {
                continue;
            }
            if (excludedArea != null && excludedArea.contains(candidate)) {
                continue;
            }
            if (requireWalkable && !isCombatSceneWalkable(candidate)) {
                continue;
            }
            result.add(candidate);
        }
        return result;
    }

    private WorldArea getNpcArea(Rs2NpcModel brutus) {
        return Microbot.getClientThread().runOnClientThreadOptional(() ->
                brutus == null || brutus.getNpc() == null ? null : brutus.getNpc().getWorldArea()
        ).orElse(null);
    }

    private int getNpcOrientation(Rs2NpcModel brutus) {
        return Microbot.getClientThread().runOnClientThreadOptional(() -> {
            NPC npc = brutus == null ? null : brutus.getNpc();
            if (npc == null) {
                return -1;
            }
            int orientation = npc.getOrientation();
            return orientation >= 0 ? orientation : npc.getCurrentOrientation();
        }).orElse(-1);
    }

    private boolean isPlayerOnSpecialTarget() {
        return playerSpecialCandidate() != null;
    }

    private WorldPoint playerSpecialCandidate() {
        WorldPoint player = getCombatScenePlayerLocation();
        if (player == null) {
            return null;
        }
        if (specialDodgeTarget != null && player.equals(specialDodgeTarget)) {
            return specialDodgeTarget;
        }
        for (WorldPoint candidate : specialDodgeCandidates) {
            if (player.equals(candidate)) {
                return candidate;
            }
        }
        return null;
    }

    private WorldPoint getCombatScenePlayerLocation() {
        return Microbot.getClientThread().runOnClientThreadOptional(() -> {
            Player player = Microbot.getClient().getLocalPlayer();
            return player == null ? null : player.getWorldLocation();
        }).orElse(null);
    }

    private boolean isCombatSceneWalkable(WorldPoint worldPoint) {
        if (worldPoint == null) {
            return false;
        }
        LocalPoint localPoint = Microbot.getClientThread()
                .runOnClientThreadOptional(() -> {
                    SceneWalkProjection projection = projectCombatSceneTile(worldPoint);
                    return projection.localPoint;
                })
                .orElse(null);
        return localPoint != null && Rs2Tile.isWalkable(localPoint);
    }

    private void clearWalkerRouteIfActive(String reason) {
        if (Rs2Walker.getCurrentTarget() != null) {
            Rs2Walker.clearWalkingRoute(reason);
        }
    }

    private int currentGameTick() {
        return Microbot.getClientThread().runOnClientThreadOptional(
                () -> Microbot.getClient().getTickCount()
        ).orElse(Integer.MIN_VALUE);
    }

    private boolean isBrutusMoving(Rs2NpcModel brutus) {
        return Microbot.getClientThread().runOnClientThreadOptional(() -> {
            NPC npc = brutus == null ? null : brutus.getNpc();
            return npc != null && npc.getPoseAnimation() != npc.getIdlePoseAnimation();
        }).orElse(false);
    }

    private SpecialAttack specialForAnimation(int animation) {
        // Trigger on the actual Brutus action animations. The remaining generated
        // transition animations are kept in CHARGE_ANIMATIONS/STOMP_ANIMATIONS so
        // the state remains active, but they do not create duplicate dodge clicks.
        if (animation == AnimationID.COW_BOSS_HEAVY_BREATH
                || animation == AnimationID.COW_BOSS_CHARGE
                || animation == AnimationID.COW_BOSS_GHOST_CHARGE) {
            return SpecialAttack.CHARGE;
        }
        // Trigger on the earliest generated Stomp phase, including fade-in. The
        // sequence latch prevents later transition animations from creating a
        // second dodge for the same Stomp.
        if (STOMP_ANIMATIONS.contains(animation)) {
            return SpecialAttack.STOMP;
        }
        return SpecialAttack.NONE;
    }

    private boolean isAnimationFor(SpecialAttack attack, int animation) {
        return attack == SpecialAttack.CHARGE
                ? CHARGE_ANIMATIONS.contains(animation)
                : attack == SpecialAttack.STOMP && STOMP_ANIMATIONS.contains(animation);
    }

    private String normalizeSpecialCue(String overheadText) {
        if (overheadText == null) {
            return "";
        }
        String normalized = overheadText.toLowerCase(Locale.ROOT);
        if (normalized.contains("growl")) {
            return "charge";
        }
        if (normalized.contains("snort")) {
            return "stomp";
        }
        return "";
    }

    private synchronized void clearSpecialAvoidance() {
        activeSpecial = SpecialAttack.NONE;
        specialAnimationObserved = false;
        specialMovementAttempted = false;
        lastSpecialMovementTick = Integer.MIN_VALUE;
        specialMovementIssueCount = 0;
        specialMovementTargetAttempts = 0;
        specialMovementLastProgressTick = Integer.MIN_VALUE;
        specialMovementLastPlayerLocation = null;
        specialMovementIssuedTargets.clear();
        specialTargetReached = false;
        specialDodgeTarget = null;
        specialDodgeCandidates = List.of();
        specialCandidateIndex = 0;
        lastSpecialReattackTick = Integer.MIN_VALUE;
        activeSpecialStartedTick = Integer.MIN_VALUE;
        stompActivationTick = Integer.MIN_VALUE;
        stompReattackIssued = false;
        stompReattackIssuedTick = Integer.MIN_VALUE;
    }

    private synchronized void resetSpecialDetection() {
        clearSpecialAvoidance();
        pendingSpecial = SpecialAttack.NONE;
        pendingSpecialFromAnimation = false;
        pendingSpecialAnimation = -1;
        pendingSpecialArea = null;
        pendingSpecialOrientation = -1;
        cuePrimedAttack = SpecialAttack.NONE;
        cuePrimedTick = Integer.MIN_VALUE;
        chargeSequenceLatched = false;
        chargeSequenceAnimationObserved = false;
        stompSequenceLatched = false;
        currentBrutusAnimation = -1;
        currentBrutusAnimationFrame = -1;
        lastObservedBrutusAnimation = Integer.MIN_VALUE;
        lastObservedBrutusFrame = -1;
        lastObservedOverheadCue = "";
        if (!stompImpactTileTicks.isEmpty()) {
            stompImpactTileTicks.clear();
        }
    }

    private boolean useStatBoostingPotionIfNeeded() {
        if (!config.useStatBoostingPotions() || !playerReadyForAction()) {
            return false;
        }

        for (String potionName : potionPrioritiesForMode(combatMode)) {
            Rs2ItemModel potion = findInventoryPotion(potionName);
            if (potion == null) {
                continue;
            }
            boolean needsBoost = needsPotionBoost(potion.getName());
            int gameTick = currentGameTick();
            if (gameTick != lastPotionDebugTick) {
                lastPotionDebugTick = gameTick;
                visibleDebug("Potion", "check item=" + potion.getName()
                        + " needsDose=" + needsBoost
                        + " stats=" + Arrays.toString(readCombatStats()));
            }
            if (!needsBoost) {
                continue;
            }
            setState(KspMadCowState.USING_POTION, "Drinking " + potion.getName());
            boolean clicked = Rs2Inventory.interact(potion, "Drink");
            if (!clicked) {
                clicked = Rs2Inventory.interact(potion, "drink");
            }
            visibleDebug("Potion", "drink issued=" + clicked + " item=" + potion.getName());
            if (clicked) {
                combatReacquirePending = true;
            }
            return clicked;
        }
        return false;
    }

    private boolean needsPotionBoost(String potionName) {
        String name = potionName == null ? "" : potionName.toLowerCase(Locale.ROOT);
        int[] stats = readCombatStats();
        int attackBoosted = stats[0];
        int attackReal = stats[1];
        int strengthBoosted = stats[2];
        int strengthReal = stats[3];
        int defenceBoosted = stats[4];
        int defenceReal = stats[5];
        int rangedBoosted = stats[6];
        int rangedReal = stats[7];
        int magicBoosted = stats[8];
        int magicReal = stats[9];

        // Re-dose only when every positive boost supplied by that potion has
        // completely expired. A partial decay must never consume another dose.
        if (name.contains("combat potion")) {
            return attackBoosted <= attackReal
                    && strengthBoosted <= strengthReal
                    && defenceBoosted <= defenceReal;
        }
        if (name.contains("bastion")) {
            return rangedBoosted <= rangedReal && defenceBoosted <= defenceReal;
        }
        if (name.contains("battlemage")) {
            return magicBoosted <= magicReal && defenceBoosted <= defenceReal;
        }
        if (name.contains("strength")) {
            return strengthBoosted <= strengthReal;
        }
        if (name.contains("attack")) {
            return attackBoosted <= attackReal;
        }
        if (name.contains("defence") || name.contains("defense")) {
            return defenceBoosted <= defenceReal;
        }
        if (name.contains("ranging")) {
            return rangedBoosted <= rangedReal;
        }
        if (name.contains("magic")) {
            return magicBoosted <= magicReal;
        }
        return false;
    }

    private String findPotionToWithdrawFromBank() {
        if (!config.useStatBoostingPotions()) {
            return null;
        }

        String[] priorities = potionPrioritiesForMode(combatMode);
        if (hasAnyInventoryPotion(priorities)) {
            return null;
        }

        for (String name : priorities) {
            if (Rs2Bank.hasBankItem(name, 1, false)) {
                return name;
            }
        }
        return null;
    }

    private String[] potionPrioritiesForMode(CombatMode mode) {
        if (mode == CombatMode.RANGED) {
            return RANGED_POTIONS;
        }
        if (mode == CombatMode.MAGIC) {
            return MAGIC_POTIONS;
        }
        List<String> names = new ArrayList<>();
        names.addAll(Arrays.asList(MELEE_COMBINED_POTIONS));
        names.addAll(Arrays.asList(STRENGTH_POTIONS));
        names.addAll(Arrays.asList(ATTACK_POTIONS));
        names.addAll(Arrays.asList(DEFENCE_POTIONS));
        return names.toArray(new String[0]);
    }

    private boolean hasAnyInventoryPotion(String[] names) {
        for (String name : names) {
            if (findInventoryPotion(name) != null) {
                return true;
            }
        }
        return false;
    }

    private Rs2ItemModel findInventoryPotion(String baseName) {
        String normalized = baseName.toLowerCase(Locale.ROOT);
        return Rs2Inventory.all().stream()
                .filter(item -> item.getName() != null)
                .filter(item -> {
                    String itemName = item.getName().toLowerCase(Locale.ROOT);
                    return itemName.equals(normalized) || itemName.startsWith(normalized + "(");
                })
                .findFirst()
                .orElse(null);
    }

    private boolean isKnownStatPotion(String itemName) {
        if (itemName == null) {
            return false;
        }
        for (CombatMode mode : CombatMode.values()) {
            for (String potion : potionPrioritiesForMode(mode)) {
                String normalized = potion.toLowerCase(Locale.ROOT);
                String item = itemName.toLowerCase(Locale.ROOT);
                if (item.equals(normalized) || item.startsWith(normalized + "(")) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean buryBones() {
        if (!config.buryBones() || !playerReadyForAction()) {
            return false;
        }

        Rs2TileItemModel groundBones = Microbot.getRs2TileItemCache().query()
                .where(item -> item.isLootAble() && isBones(item.getName()))
                .within(config.lootRadius())
                .nearestOnClientThread();
        if (groundBones != null) {
            setState(KspMadCowState.BURYING_BONES, "Burying " + groundBones.getName());
            return groundBones.click("Bury");
        }

        List<Rs2ItemModel> inventoryBones = Rs2Inventory.getBones();
        if (!inventoryBones.isEmpty()) {
            Rs2ItemModel bones = inventoryBones.get(0);
            setState(KspMadCowState.BURYING_BONES, "Burying " + bones.getName());
            return Rs2Inventory.interact(bones, "Bury");
        }
        return false;
    }

    private boolean lootOneItem() {
        if (!config.lootAll() || !playerReadyForAction()) {
            return false;
        }

        Rs2TileItemModel loot = Microbot.getRs2TileItemCache().query()
                .where(item -> item.isLootAble() && !isBones(item.getName()))
                .within(config.lootRadius())
                .nearestOnClientThread();
        if (loot == null) {
            return false;
        }

        boolean fits = !Rs2Inventory.isFull() || (loot.isStackable() && Rs2Inventory.hasItem(loot.getId()));
        if (!fits) {
            return false;
        }

        setState(KspMadCowState.LOOTING, "Taking " + loot.getName());
        return loot.pickup();
    }

    private boolean quickLeave(ObjectAction knownQuickLeave, String reason) {
        ObjectAction quickLeave = knownQuickLeave != null
                ? knownQuickLeave
                : findObjectAction(QUICK_ESCAPE_ACTIONS);
        if (quickLeave == null) {
            setState(KspMadCowState.ERROR, "Quick-escape gate not found: " + reason);
            return false;
        }

        leavingInstance = true;
        quickLeaveClickIssued = false;
        setState(KspMadCowState.LEAVING_INSTANCE, reason + "; using Quick-escape gate");
        if (playerReadyForAction() && quickLeave.object.click(quickLeave.action)) {
            quickLeaveClickIssued = true;
        }
        return true;
    }

    private void attackBrutus(Rs2NpcModel brutus) {
        if (isPlayerTargetingAnyBrutus()) {
            combatReacquirePending = false;
            lastCombatBlockedReason = "";
            setState(KspMadCowState.FIGHTING, "Fighting Brutus");
            return;
        }

        // Once the player has no Brutus interaction target, keep combat
        // reacquisition at the top of the inside-instance priority chain. This is
        // especially important after eating, drinking, Charge and Stomp.
        combatReacquirePending = true;

        Rs2NpcModel idBrutus = findBrutus();
        if (idBrutus == null) {
            idBrutus = brutus;
        }
        if (idBrutus == null || idBrutus.getNpc() == null
                || !isBrutusIdNpc(idBrutus.getNpc())) {
            logCombatBlockedOnce("normal attack", "Brutus NPC IDs not found");
            return;
        }

        setState(KspMadCowState.FIGHTING,
                combatReacquirePending
                        ? "Re-attacking Brutus after movement/action"
                        : "Attacking Brutus");

        // Re-click Brutus whenever the player is no longer animating and has no
        // Brutus interaction target. Movement is not an additional blocker.
        if (isPlayerCurrentlyAnimating()) {
            logCombatBlockedOnce("normal attack", "player animating");
            return;
        }

        int gameTick = currentGameTick();
        if (gameTick != Integer.MIN_VALUE && gameTick == lastCombatAttackTick) {
            return;
        }
        lastCombatAttackTick = gameTick;
        lastCombatBlockedReason = "";

        boolean issued = invokeBrutusAttackById(idBrutus,
                combatReacquirePending ? "combat reacquire" : "normal attack");
        visibleDebug("Combat", "attack issued=" + issued
                + " tick=" + gameTick
                + " npcId=" + idBrutus.getId()
                + " npcIndex=" + idBrutus.getIndex()
                + " reacquirePending=" + combatReacquirePending
                + " moving=" + Rs2Player.isMoving()
                + " scenePlayer=" + getCombatScenePlayerLocation()
                + " cachedPlayer=" + Rs2Player.getWorldLocation());
        combatReacquirePending = true;
    }

    private boolean invokeBrutusAttackById(Rs2NpcModel brutus, String context) {
        if (brutus == null || brutus.getNpc() == null) {
            visibleDebug("Combat", context + " rejected: Brutus model is null");
            return false;
        }

        // RuneLite actor fields are client-thread guarded. The client-thread fix resolved the
        // Attack option on the client thread, but then read npc.getName() and the
        // actor clickbox from KspMadCowScript-main. That threw before doInvoke could
        // submit the menu action. Build and invoke the complete NPC interaction on
        // the client thread and return only immutable diagnostic data to the script.
        AttackInvokeResult result;
        try {
            result = Microbot.getClientThread().runOnClientThreadOptional(() -> {
                NPC npc = brutus.getNpc();
                if (npc == null) {
                    return AttackInvokeResult.failure(-1, -1, AttackMenuResolution.NONE,
                            "NPC disappeared before client-thread invocation");
                }

                int npcId = npc.getId();
                int npcIndex = npc.getIndex();
                if (npcId != BRUTUS_ID && npcId != BRUTUS_ALT_ID) {
                    return AttackInvokeResult.failure(npcId, npcIndex,
                            AttackMenuResolution.NONE, "resolved actor is not a Brutus ID");
                }

                AttackMenuResolution resolution = resolveAttackMenu(npc);
                if (!resolution.available()) {
                    return AttackInvokeResult.failure(npcId, npcIndex, resolution,
                            "Attack option unavailable");
                }

                String npcName = npc.getName();
                Rectangle clickbox = Rs2UiHelper.getActorClickbox(npc);
                if (clickbox == null) {
                    clickbox = new Rectangle(1, 1, 1, 1);
                }

                // Do not retain the live NPC actor in NewMenuEntry. VirtualMouse can
                // otherwise re-read its clickbox later from its executor thread. The
                // NPC index and resolved NPC_*_OPTION are sufficient for the action.
                Microbot.doInvoke(
                        new NewMenuEntry()
                                .option("Attack")
                                .target(npcName == null ? BRUTUS_NAME : npcName)
                                .identifier(npcIndex)
                                .type(resolution.menuAction)
                                .param0(0)
                                .param1(0)
                                .itemId(-1),
                        clickbox
                );
                return AttackInvokeResult.success(npcId, npcIndex, resolution);
            }).orElse(AttackInvokeResult.failure(-1, -1, AttackMenuResolution.NONE,
                    "client-thread invocation returned no result"));
        } catch (Exception ex) {
            log.warn("[KSP Mad Cow][Combat] Client-thread Attack invoke failed context={}", context, ex);
            visibleDebug("Combat", context + " client-thread invoke exception="
                    + ex.getClass().getSimpleName());
            return false;
        }

        if (!result.issued) {
            visibleDebug("Combat", context + " not issued"
                    + " reason=" + result.failureReason
                    + " npcId=" + result.npcId
                    + " npcIndex=" + result.npcIndex
                    + " actions=" + result.resolution.actionsSummary);
            return false;
        }

        visibleDebug("Combat", context + " menu invoke"
                + " npcId=" + result.npcId
                + " npcIndex=" + result.npcIndex
                + " optionIndex=" + result.resolution.optionIndex
                + " menuAction=" + result.resolution.menuAction
                + " actions=" + result.resolution.actionsSummary
                + " thread=client");
        return true;
    }

    private AttackMenuResolution resolveAttackMenu(NPC npc) {
        if (npc == null) {
            return AttackMenuResolution.NONE;
        }

        NPCComposition transformed = npc.getTransformedComposition();
        NPCComposition base = npc.getComposition();
        NPCComposition definition = Microbot.getClient().getNpcDefinition(npc.getId());
        NPCComposition[] compositions = {transformed, base, definition};
        StringBuilder summaries = new StringBuilder();

        for (int sourceIndex = 0; sourceIndex < compositions.length; sourceIndex++) {
            NPCComposition composition = compositions[sourceIndex];
            if (composition == null) {
                continue;
            }
            if (sourceIndex > 0 && composition == compositions[sourceIndex - 1]) {
                continue;
            }

            String[] actions = composition.getActions();
            if (summaries.length() > 0) {
                summaries.append(" | ");
            }
            summaries.append(sourceIndex == 0 ? "transformed="
                    : sourceIndex == 1 ? "base=" : "definition=")
                    .append(actions == null ? "null" : Arrays.toString(actions));
            if (actions == null) {
                continue;
            }

            for (int index = 0; index < Math.min(actions.length, 5); index++) {
                String action = actions[index];
                if (action != null && action.equalsIgnoreCase("Attack")) {
                    return new AttackMenuResolution(
                            index,
                            npcMenuAction(index),
                            summaries.toString()
                    );
                }
            }
        }

        return new AttackMenuResolution(
                -1,
                null,
                summaries.length() == 0 ? "no-composition" : summaries.toString()
        );
    }

    private MenuAction npcMenuAction(int index) {
        switch (index) {
            case 0: return MenuAction.NPC_FIRST_OPTION;
            case 1: return MenuAction.NPC_SECOND_OPTION;
            case 2: return MenuAction.NPC_THIRD_OPTION;
            case 3: return MenuAction.NPC_FOURTH_OPTION;
            case 4: return MenuAction.NPC_FIFTH_OPTION;
            default: return null;
        }
    }

    private void logCombatBlockedOnce(String context, String reason) {
        int gameTick = currentGameTick();
        String key = context + ":" + reason;
        if (key.equals(lastCombatBlockedReason)
                && gameTick != Integer.MIN_VALUE
                && lastCombatBlockedLogTick != Integer.MIN_VALUE
                && gameTick - lastCombatBlockedLogTick < 5) {
            return;
        }
        lastCombatBlockedLogTick = gameTick;
        lastCombatBlockedReason = key;
        visibleDebug("Combat", context + " blocked=" + reason
                + " tick=" + gameTick
                + " player=" + Rs2Player.getWorldLocation()
                + " animation=" + currentPlayerAnimation()
                + " moving=" + Rs2Player.isMoving()
                + " targetingBrutus=" + isPlayerTargetingBrutusId());
    }

    private int currentPlayerAnimation() {
        return Microbot.getClientThread().runOnClientThreadOptional(() -> {
            Player player = Microbot.getClient().getLocalPlayer();
            return player == null ? -1 : player.getAnimation();
        }).orElse(-1);
    }

    private boolean isPlayerTargetingBrutus(Rs2NpcModel brutus) {
        return isPlayerTargetingBrutusId();
    }

    private boolean isPlayerTargetingAnyBrutus() {
        return isPlayerTargetingBrutusId();
    }

    private boolean isPlayerTargetingBrutusId() {
        return Microbot.getClientThread().runOnClientThreadOptional(() -> {
            Player player = Microbot.getClient().getLocalPlayer();
            Actor target = player == null ? null : player.getInteracting();
            return target instanceof NPC && isBrutusIdNpc((NPC) target);
        }).orElse(false);
    }

    private boolean playerReadyForAction() {
        return !Rs2Player.isMoving() && !isPlayerCurrentlyAnimating();
    }

    private boolean isPlayerCurrentlyAnimating() {
        return Microbot.getClientThread().runOnClientThreadOptional(() -> {
            Player player = Microbot.getClient().getLocalPlayer();
            return player != null && player.getAnimation() != -1;
        }).orElse(false);
    }

    private boolean isClientInInstancedRegion() {
        return Microbot.getClientThread().runOnClientThreadOptional(() -> {
            var worldView = Microbot.getClient().getTopLevelWorldView();
            return worldView != null && worldView.isInstance();
        }).orElse(false);
    }

    private boolean isBrutusIdNpc(NPC npc) {
        if (npc == null) {
            return false;
        }
        int id = npc.getId();
        return id == BRUTUS_ID || id == BRUTUS_ALT_ID;
    }

    private boolean isNamedBrutus(NPC npc) {
        if (npc == null) {
            return false;
        }
        String name = npc.getName();
        return name != null && name.equalsIgnoreCase(BRUTUS_NAME);
    }

    private Rs2NpcModel findBrutus() {
        Rs2NpcModel cached = Microbot.getRs2NpcCache().query()
                .withIds(BRUTUS_ID, BRUTUS_ALT_ID)
                .nearestOnClientThread();
        if (cached != null && cached.getNpc() != null) {
            lastKnownBrutusNpc = cached.getNpc();
            return cached;
        }

        // Charge can briefly outrun the asynchronous Microbot NPC cache. Fall back
        // to RuneLite's live WorldView so the rear-tile re-attack state is not lost.
        Rs2NpcModel live = Microbot.getClientThread().runOnClientThreadOptional(() -> {
            var worldView = Microbot.getClient().getTopLevelWorldView();
            if (worldView == null) {
                return null;
            }

            Player player = Microbot.getClient().getLocalPlayer();
            WorldPoint playerLocation = player == null ? null : player.getWorldLocation();
            NPC nearest = null;
            int nearestDistance = Integer.MAX_VALUE;

            for (NPC npc : worldView.npcs()) {
                if (npc == null || !isBrutusIdNpc(npc)) {
                    continue;
                }

                WorldPoint npcLocation = npc.getWorldLocation();
                int distance = playerLocation == null || npcLocation == null
                        ? 0
                        : playerLocation.distanceTo2D(npcLocation);
                if (nearest == null || distance < nearestDistance) {
                    nearest = npc;
                    nearestDistance = distance;
                }
            }

            return nearest == null ? null : new Rs2NpcModel(nearest);
        }).orElse(null);
        if (live != null && live.getNpc() != null) {
            lastKnownBrutusNpc = live.getNpc();
        }
        return live;
    }

    private boolean isAlive(Rs2NpcModel brutus) {
        if (brutus == null || brutus.getNpc() == null) {
            return false;
        }
        return Microbot.getClientThread().runOnClientThreadOptional(
                () -> !brutus.getNpc().isDead()
        ).orElse(false);
    }

    public synchronized void onBrutusDeath(Actor actor) {
        if (!running || !instanceConfirmed || !killArmed || !isBrutusActor(actor)) {
            return;
        }
        killArmed = false;
        killCount++;
        brutusAlive = false;
        prayersSuppressedUntilRespawn = true;
        disableManagedCombatPrayers();
        resetSpecialDetection();
        combatReacquirePending = false;
        setMessage("Brutus defeated; prayers disabled; kill count " + killCount);
    }

    private boolean isBrutusActor(Actor actor) {
        if (!(actor instanceof NPC)) {
            return false;
        }
        NPC npc = (NPC) actor;
        NPC remembered = lastKnownBrutusNpc;
        if (remembered != null && remembered.getIndex() == npc.getIndex()) {
            return true;
        }

        int id = npc.getId();
        if (id == BRUTUS_ID || id == BRUTUS_ALT_ID) {
            return true;
        }
        return isNamedBrutus(npc);
    }

    private ObjectAction findObjectAction(String... requestedActions) {
        String[] requested = Arrays.stream(requestedActions)
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(value -> !value.isEmpty())
                .toArray(String[]::new);
        if (requested.length == 0) {
            return null;
        }

        Rs2TileObjectModel object = Microbot.getRs2TileObjectCache().query()
                .where(candidate -> matchingAction(candidate, requested) != null)
                .nearestOnClientThread();
        if (object == null) {
            return null;
        }
        String action = matchingAction(object, requested);
        return action == null ? null : new ObjectAction(object, action);
    }

    private String matchingAction(Rs2TileObjectModel object, String[] requestedActions) {
        try {
            if (object == null || object.getObjectComposition() == null) {
                return null;
            }
            String[] actions = object.getObjectComposition().getActions();
            if (actions == null) {
                return null;
            }

            for (String requested : requestedActions) {
                String normalizedRequested = normalizeAction(requested);
                for (String actual : actions) {
                    if (actual == null) {
                        continue;
                    }
                    String normalizedActual = normalizeAction(actual);
                    if (normalizedActual.equals(normalizedRequested)
                            || normalizedActual.contains(normalizedRequested)) {
                        return actual;
                    }
                }
            }
        } catch (Exception ignored) {
            // Object may transform or disappear during lookup.
        }
        return null;
    }

    private boolean interactInventoryFirstAvailable(int itemId, String... preferredActions) {
        Rs2ItemModel item = Rs2Inventory.get(itemId);
        if (item == null || item.getInventoryActions() == null) {
            return false;
        }
        for (String preferred : preferredActions) {
            for (String actual : item.getInventoryActions()) {
                if (actual != null && normalizeAction(actual).equals(normalizeAction(preferred))) {
                    return Rs2Inventory.interact(item, actual);
                }
            }
        }
        return false;
    }

    private String normalizeAction(String action) {
        return action.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    private int getConfiguredFoodQuantity() {
        return config == null ? 0 : Rs2Inventory.itemQuantity(config.food().getId());
    }

    private boolean hasConfiguredFood() {
        return getConfiguredFoodQuantity() > 0;
    }

    private boolean hasRequiredFoodAmount() {
        return getConfiguredFoodQuantity() >= Math.max(1, config.foodAmount());
    }

    private boolean hasCowbell() {
        return Rs2Inventory.hasItem(COWBELL_EMPTY_ID, COWBELL_CHARGED_ID)
                || Rs2Equipment.isWearing(COWBELL_EMPTY_ID, COWBELL_CHARGED_ID);
    }

    private boolean isBones(String name) {
        return name != null && name.toLowerCase(Locale.ROOT).contains("bones");
    }

    private WorldPoint offset(WorldPoint point, int x, int y) {
        return new WorldPoint(point.getX() + x, point.getY() + y, point.getPlane());
    }

    private int clamp(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private boolean isWalkable(WorldPoint point) {
        try {
            return Rs2Tile.isWalkable(Rs2LocalPoint.fromWorldInstance(point));
        } catch (Exception ignored) {
            return false;
        }
    }

    private int hitpointsPercent() {
        int[] values = readLevels(Skill.HITPOINTS);
        return values[0] * 100 / Math.max(1, values[1]);
    }

    private int getCurrentPrayerPointsSafe() {
        return readLevels(Skill.PRAYER)[0];
    }

    private int getRealPrayerLevelSafe() {
        return readLevels(Skill.PRAYER)[1];
    }

    private int[] readLevels(Skill... skills) {
        return Microbot.getClientThread().runOnClientThreadOptional(() -> {
            int[] values = new int[skills.length * 2];
            for (int i = 0; i < skills.length; i++) {
                values[i * 2] = Microbot.getClient().getBoostedSkillLevel(skills[i]);
                values[i * 2 + 1] = Microbot.getClient().getRealSkillLevel(skills[i]);
            }
            return values;
        }).orElse(new int[skills.length * 2]);
    }

    private int[] readCombatStats() {
        return readLevels(Skill.ATTACK, Skill.STRENGTH, Skill.DEFENCE, Skill.RANGED, Skill.MAGIC);
    }

    private void supplyFailure(String message) {
        setState(KspMadCowState.ERROR, message);
        if (!suppliesErrorShown) {
            suppliesErrorShown = true;
            Microbot.showMessage(message);
        }
        if (config.shutdownOnMissingSupplies()) {
            requestPluginStop();
        }
    }

    private void requestPluginStop() {
        Runnable callback = stopRequest;
        if (callback != null) {
            callback.run();
        } else {
            shutdown();
        }
    }

    private void visibleDebug(String category, String message) {
        if (config != null && !config.debugLogging()) {
            return;
        }
        String line = "[KSP Mad Cow][" + category + "] " + message;
        try {
            // Microbot.log writes at INFO through Microbot's own logger, which is
            // the stream shown by the Microbot log panel.
            Microbot.log(line);
        } catch (Exception ex) {
            log.info(line);
            log.debug("Unable to forward KSP Mad Cow debug message to Microbot log", ex);
        }
    }

    private void setState(KspMadCowState newState, String message) {
        state = newState;
        setMessage(message);
    }

    private void setMessage(String message) {
        lastMessage = message;
        Microbot.status = message;
    }

    private void refreshOverlaySnapshot() {
        try {
            int[] hpPrayer = readLevels(Skill.HITPOINTS, Skill.PRAYER);
            int hpPercent = hpPrayer[0] * 100 / Math.max(1, hpPrayer[1]);
            int prayerCurrent = hpPrayer[2];
            int prayerReal = hpPrayer[3];
            long elapsed = elapsedRuntimeMillis();
            double killsPerHour = elapsed <= 0L ? 0.0 : killCount * 3_600_000.0 / elapsed;

            overlaySnapshot = new OverlaySnapshot(
                    formatRuntime(elapsed),
                    killCount,
                    String.format(Locale.ROOT, "%.1f", killsPerHour),
                    state,
                    lastMessage,
                    instanceConfirmed,
                    clientInstanceDetected,
                    travelPhaseSummary(),
                    bossStatus(),
                    combatMode.getDisplayName(),
                    trainingDisplay(),
                    hpPercent,
                    prayerCurrent,
                    prayerReal,
                    prayerPlanSummary(prayerReal),
                    activePrayerSummary,
                    activeSpecialSummary(),
                    currentBrutusAnimation,
                    currentBrutusAnimationFrame,
                    specialTargetSummary(),
                    combatReacquirePending,
                    config == null ? "Food" : config.food().getName(),
                    getConfiguredFoodQuantity(),
                    config == null ? 0 : Math.max(1, config.foodAmount()),
                    Rs2Inventory.fullSlotCount(),
                    cowbellStatus(),
                    Rs2Inventory.itemQuantity(AIR_RUNE_ID),
                    mooletaStatus(),
                    altarRestorePending,
                    potionStatus(),
                    running
            );
        } catch (Exception ex) {
            log.debug("Unable to refresh Brutus overlay snapshot", ex);
        }
    }

    private long elapsedRuntimeMillis() {
        if (running && startedAtNanos > 0L) {
            return Math.max(0L, TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startedAtNanos));
        }
        return stoppedElapsedMillis;
    }

    private String formatRuntime(long elapsedMillis) {
        long secondsTotal = elapsedMillis / 1_000L;
        long hours = secondsTotal / 3_600L;
        long minutes = (secondsTotal % 3_600L) / 60L;
        long seconds = secondsTotal % 60L;
        return String.format(Locale.ROOT, "%02d:%02d:%02d", hours, minutes, seconds);
    }

    private String travelPhaseSummary() {
        if (leavingInstance) {
            return "Leaving instance";
        }
        if (instanceConfirmed) {
            return "Inside instance";
        }
        if (!travelRequired) {
            return cowbellTravelIssued ? "Travelling to pen" : "At/entering pen";
        }
        if (initialBankCheckPending) {
            return "Restocking";
        }
        return "Cowbell armed";
    }

    private String bossStatus() {
        if (brutusAlive) {
            return "Alive";
        }
        if (instanceConfirmed) {
            return "Respawning";
        }
        return "Outside instance";
    }

    private String trainingDisplay() {
        if (combatMode == CombatMode.RANGED) {
            return "Ranged";
        }
        if (combatMode == CombatMode.MAGIC) {
            return "Magic";
        }
        return config != null && config.balanceCombatStats()
                ? trainingSkill.getName()
                : "Current melee style";
    }

    private String prayerPlanSummary(int prayerLevel) {
        Rs2PrayerEnum[] desired = desiredPrayersFor(combatMode, prayerLevel);
        if (desired.length == 0) {
            return "None at current level";
        }
        List<String> names = new ArrayList<>();
        for (Rs2PrayerEnum prayer : desired) {
            names.add(prayer.getName());
        }
        return String.join(" + ", names);
    }

    private String activeSpecialSummary() {
        if (activeSpecial == SpecialAttack.CHARGE) {
            return "Charge";
        }
        if (activeSpecial == SpecialAttack.STOMP) {
            return "Stomp";
        }
        return "None";
    }

    private String specialTargetSummary() {
        if (specialDodgeTarget == null) {
            return "None";
        }
        return specialDodgeTarget.getX() + ", " + specialDodgeTarget.getY() + ", " + specialDodgeTarget.getPlane();
    }

    private String cowbellStatus() {
        if (Rs2Equipment.isWearing(COWBELL_CHARGED_ID)) {
            return "Charged (equipped)";
        }
        if (Rs2Inventory.hasItem(COWBELL_CHARGED_ID)) {
            return "Charged";
        }
        if (Rs2Equipment.isWearing(COWBELL_EMPTY_ID)) {
            return "Empty (equipped)";
        }
        if (Rs2Inventory.hasItem(COWBELL_EMPTY_ID)) {
            return "Empty";
        }
        return "Missing";
    }

    private String mooletaStatus() {
        if (combatMode != CombatMode.MELEE || config == null || !config.equipMooleta()) {
            return "Not required";
        }
        if (Rs2Equipment.isWearing(MOOLETA_ID)) {
            return "Equipped";
        }
        if (Rs2Inventory.hasItem(MOOLETA_ID)) {
            return "Inventory";
        }
        return "Not available";
    }

    private String potionStatus() {
        if (config == null || !config.useStatBoostingPotions()) {
            return "Disabled";
        }
        for (String potion : potionPrioritiesForMode(combatMode)) {
            Rs2ItemModel item = findInventoryPotion(potion);
            if (item != null) {
                return item.getName();
            }
        }
        return "None carried";
    }

    public KspMadCowState getState() {
        return state;
    }

    public Skill getTrainingSkill() {
        return trainingSkill;
    }

    public int getKillCount() {
        return killCount;
    }

    public String getLastMessage() {
        return lastMessage;
    }

    public CombatMode getCombatMode() {
        return combatMode;
    }

    public String getActivePrayerSummary() {
        return activePrayerSummary;
    }

    public boolean isBrutusAlive() {
        return brutusAlive;
    }

    public OverlaySnapshot getOverlaySnapshot() {
        return overlaySnapshot;
    }

    @Override
    public synchronized void shutdown() {
        if (!running && state == KspMadCowState.STOPPED) {
            return;
        }

        stoppedElapsedMillis = elapsedRuntimeMillis();
        running = false;

        if (mainScheduledFuture != null && !mainScheduledFuture.isDone()) {
            mainScheduledFuture.cancel(true);
        }
        super.shutdown();

        if (scheduledExecutorService != null && !scheduledExecutorService.isShutdown()) {
            scheduledExecutorService.shutdownNow();
        }

        try {
            if (Microbot.isLoggedIn()) {
                disableManagedCombatPrayers();
            }
        } catch (Exception ex) {
            log.debug("Unable to disable Brutus prayers during shutdown", ex);
        }

        clearWalkerRouteIfActive("brutus-shutdown");
        resetSpecialDetection();
        bankActionPending = false;
        bankActionComplete = null;
        leavingInstance = false;
        quickLeaveClickIssued = false;
        cowbellTravelIssued = false;
        altarInteractionIssued = false;
        altarRestorePending = false;
        altarPrayerPointsBeforeInteraction = -1;
        altarTeleportPending = false;
        clearHealActionState();
        instanceConfirmed = false;
        clientInstanceDetected = false;
        combatReacquirePending = false;
        lastCombatAttackTick = Integer.MIN_VALUE;
        lastCombatBlockedLogTick = Integer.MIN_VALUE;
        lastCombatBlockedReason = "";
        lastRangedAmmoEquipTick = Integer.MIN_VALUE;
        trackedRangedAmmoId = -1;
        trackedRangedAmmoName = "";
        lastHealDebugTick = Integer.MIN_VALUE;
        lastPotionDebugTick = Integer.MIN_VALUE;
        killArmed = false;
        prayersSuppressedUntilRespawn = false;
        lastKnownBrutusNpc = null;
        travelRequired = true;
        lastPenEntryAction = "";
        lastPenEntryAttemptTick = Integer.MIN_VALUE;
        initialBankCheckPending = true;
        stopRequest = null;
        state = KspMadCowState.STOPPED;
        lastMessage = "Stopped";
        Microbot.status = "KSP Mad Cow stopped";
        refreshOverlaySnapshot();
    }

    public static final class OverlaySnapshot {
        private final String runtime;
        private final int kills;
        private final String killsPerHour;
        private final KspMadCowState state;
        private final String action;
        private final boolean instanceConfirmed;
        private final boolean clientInstance;
        private final String travelPhase;
        private final String bossStatus;
        private final String combatMode;
        private final String training;
        private final int hitpointsPercent;
        private final int prayerCurrent;
        private final int prayerReal;
        private final String prayerPlan;
        private final String activePrayers;
        private final String special;
        private final int brutusAnimation;
        private final int brutusAnimationFrame;
        private final String specialTarget;
        private final boolean reattackPending;
        private final String foodName;
        private final int foodCount;
        private final int foodTarget;
        private final int inventorySlots;
        private final String cowbell;
        private final int airRunes;
        private final String mooleta;
        private final boolean altarRestore;
        private final String potion;
        private final boolean running;

        private OverlaySnapshot(
                String runtime,
                int kills,
                String killsPerHour,
                KspMadCowState state,
                String action,
                boolean instanceConfirmed,
                boolean clientInstance,
                String travelPhase,
                String bossStatus,
                String combatMode,
                String training,
                int hitpointsPercent,
                int prayerCurrent,
                int prayerReal,
                String prayerPlan,
                String activePrayers,
                String special,
                int brutusAnimation,
                int brutusAnimationFrame,
                String specialTarget,
                boolean reattackPending,
                String foodName,
                int foodCount,
                int foodTarget,
                int inventorySlots,
                String cowbell,
                int airRunes,
                String mooleta,
                boolean altarRestore,
                String potion,
                boolean running) {
            this.runtime = runtime;
            this.kills = kills;
            this.killsPerHour = killsPerHour;
            this.state = state;
            this.action = action;
            this.instanceConfirmed = instanceConfirmed;
            this.clientInstance = clientInstance;
            this.travelPhase = travelPhase;
            this.bossStatus = bossStatus;
            this.combatMode = combatMode;
            this.training = training;
            this.hitpointsPercent = hitpointsPercent;
            this.prayerCurrent = prayerCurrent;
            this.prayerReal = prayerReal;
            this.prayerPlan = prayerPlan;
            this.activePrayers = activePrayers;
            this.special = special;
            this.brutusAnimation = brutusAnimation;
            this.brutusAnimationFrame = brutusAnimationFrame;
            this.specialTarget = specialTarget;
            this.reattackPending = reattackPending;
            this.foodName = foodName;
            this.foodCount = foodCount;
            this.foodTarget = foodTarget;
            this.inventorySlots = inventorySlots;
            this.cowbell = cowbell;
            this.airRunes = airRunes;
            this.mooleta = mooleta;
            this.altarRestore = altarRestore;
            this.potion = potion;
            this.running = running;
        }

        public String getRuntime() { return runtime; }
        public int getKills() { return kills; }
        public String getKillsPerHour() { return killsPerHour; }
        public KspMadCowState getState() { return state; }
        public String getAction() { return action; }
        public boolean isInstanceConfirmed() { return instanceConfirmed; }
        public boolean isClientInstance() { return clientInstance; }
        public String getTravelPhase() { return travelPhase; }
        public String getBossStatus() { return bossStatus; }
        public String getCombatMode() { return combatMode; }
        public String getTraining() { return training; }
        public int getHitpointsPercent() { return hitpointsPercent; }
        public int getPrayerCurrent() { return prayerCurrent; }
        public int getPrayerReal() { return prayerReal; }
        public String getPrayerPlan() { return prayerPlan; }
        public String getActivePrayers() { return activePrayers; }
        public String getSpecial() { return special; }
        public int getBrutusAnimation() { return brutusAnimation; }
        public int getBrutusAnimationFrame() { return brutusAnimationFrame; }
        public String getSpecialTarget() { return specialTarget; }
        public boolean isReattackPending() { return reattackPending; }
        public String getFoodName() { return foodName; }
        public int getFoodCount() { return foodCount; }
        public int getFoodTarget() { return foodTarget; }
        public int getInventorySlots() { return inventorySlots; }
        public String getCowbell() { return cowbell; }
        public int getAirRunes() { return airRunes; }
        public String getMooleta() { return mooleta; }
        public boolean isAltarRestore() { return altarRestore; }
        public String getPotion() { return potion; }
        public boolean isRunning() { return running; }

        private static OverlaySnapshot starting() {
            return new OverlaySnapshot(
                    "00:00:00", 0, "0.0", KspMadCowState.STARTING, "Starting",
                    false, false, "Restocking", "Outside instance", "Melee", "Attack",
                    0, 0, 0, "None", "None", "None", -1, -1, "None", false,
                    "Food", 0, 0, 0, "Unknown", 0, "Unknown", false, "Disabled", true
            );
        }

        private static OverlaySnapshot stopped() {
            return new OverlaySnapshot(
                    "00:00:00", 0, "0.0", KspMadCowState.STOPPED, "Stopped",
                    false, false, "Stopped", "Outside instance", "-", "-",
                    0, 0, 0, "-", "None", "None", -1, -1, "None", false,
                    "Food", 0, 0, 0, "-", 0, "-", false, "Disabled", false
            );
        }
    }

    private static final class AttackInvokeResult {
        private final boolean issued;
        private final int npcId;
        private final int npcIndex;
        private final AttackMenuResolution resolution;
        private final String failureReason;

        private AttackInvokeResult(
                boolean issued,
                int npcId,
                int npcIndex,
                AttackMenuResolution resolution,
                String failureReason
        ) {
            this.issued = issued;
            this.npcId = npcId;
            this.npcIndex = npcIndex;
            this.resolution = resolution == null ? AttackMenuResolution.NONE : resolution;
            this.failureReason = failureReason == null ? "" : failureReason;
        }

        private static AttackInvokeResult success(
                int npcId,
                int npcIndex,
                AttackMenuResolution resolution
        ) {
            return new AttackInvokeResult(true, npcId, npcIndex, resolution, "");
        }

        private static AttackInvokeResult failure(
                int npcId,
                int npcIndex,
                AttackMenuResolution resolution,
                String reason
        ) {
            return new AttackInvokeResult(false, npcId, npcIndex, resolution, reason);
        }
    }

    private static final class AttackMenuResolution {
        private static final AttackMenuResolution NONE =
                new AttackMenuResolution(-1, null, "unresolved");

        private final int optionIndex;
        private final MenuAction menuAction;
        private final String actionsSummary;

        private AttackMenuResolution(
                int optionIndex,
                MenuAction menuAction,
                String actionsSummary
        ) {
            this.optionIndex = optionIndex;
            this.menuAction = menuAction;
            this.actionsSummary = actionsSummary;
        }

        private boolean available() {
            return optionIndex >= 0 && menuAction != null;
        }
    }

    private static final class SceneWalkProjection {
        private static final SceneWalkProjection NONE =
                new SceneWalkProjection(null, null, null);

        private final LocalPoint localPoint;
        private final Point canvasPoint;
        private final WorldPoint worldViewBase;

        private SceneWalkProjection(
                LocalPoint localPoint,
                Point canvasPoint,
                WorldPoint worldViewBase
        ) {
            this.localPoint = localPoint;
            this.canvasPoint = canvasPoint;
            this.worldViewBase = worldViewBase;
        }

        private boolean available() {
            return localPoint != null && canvasPoint != null;
        }
    }

    private static final class SpecialSignal {
        private static final SpecialSignal NONE = new SpecialSignal(
                SpecialAttack.NONE, false, -1, null, -1
        );
        private final SpecialAttack attack;
        private final boolean fromAnimation;
        @SuppressWarnings("unused")
        private final int animation;
        private final WorldArea area;
        private final int orientation;

        private SpecialSignal(
                SpecialAttack attack,
                boolean fromAnimation,
                int animation,
                WorldArea area,
                int orientation
        ) {
            this.attack = attack;
            this.fromAnimation = fromAnimation;
            this.animation = animation;
            this.area = area;
            this.orientation = orientation;
        }
    }

    private static final class BrutusAnimationSnapshot {
        private static final BrutusAnimationSnapshot NONE =
                new BrutusAnimationSnapshot(-1, -1, null, -1);

        private final int animation;
        private final int frame;
        private final WorldArea area;
        private final int orientation;

        private BrutusAnimationSnapshot(
                int animation,
                int frame,
                WorldArea area,
                int orientation
        ) {
            this.animation = animation;
            this.frame = frame;
            this.area = area;
            this.orientation = orientation;
        }
    }

    private static final class ObjectAction {
        private final Rs2TileObjectModel object;
        private final String action;

        private ObjectAction(Rs2TileObjectModel object, String action) {
            this.object = object;
            this.action = action;
        }
    }

    private final class ScriptThreadFactory implements ThreadFactory {
        @Override
        public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable, "KspMadCowScript-main");
            thread.setDaemon(true);
            return thread;
        }
    }
}
